<?php

function book_beach_register_settings() {
    register_setting( 'book_beach_settings', 'bb_righe' );
    register_setting( 'book_beach_settings', 'bb_colonne' );
    register_setting( 'book_beach_settings', 'bb_feed' );
} 
if ( is_admin() ){ // admin actions
	add_action( 'admin_init', 'book_beach_register_settings' );
} else {
  // non-admin enqueues, actions, and filters
}

?>
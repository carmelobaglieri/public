<?php
function show_book_beach_func( $atts ) {
	$righe = esc_attr( get_option('bb_righe') );
	$colonne = esc_attr( get_option('bb_colonne') );
	$feed = get_option('bb_feed');

	$html .= '<div id="book-beach-wrapper">';
	$html .= BbSearchForm();
	$html .= update_singleday_booking_results(date('Y-m-d'));
	$html .= BbRiepilogo();
	$html .= '</div>';
	
    return $html;
}
add_shortcode('book_beach', 'show_book_beach_func');
?>
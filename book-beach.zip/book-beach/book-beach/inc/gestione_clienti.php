<?php
global $file_ver;
?>

<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/fonts/fontawesome/font-awesome.min.css' );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/book-beach/css/general.css?ver=<?php echo $file_ver;?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/book-beach/css/admin_clienti.css?ver=<?php echo $file_ver;?>">

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/daterangepicker.css' );?>">
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/moment.min.js' );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/daterangepicker.min.js' );?>"></script>

<?php
wp_enqueue_script('scripts', plugins_url() . '/book-beach/js/scripts.js', null, $file_ver);
wp_localize_script('scripts', 'bbScripts', array(
        'pluginsUrl' => plugins_url().'/book-beach',
        'adminPage' => $_GET['page'],
        'feed'  => get_option('bb_feed'),
        'righe' => esc_attr( get_option('bb_righe') ),
        'colonne' => esc_attr( get_option('bb_colonne') ),
        ));
wp_enqueue_script('admin_clienti', plugins_url() . '/book-beach/js/admin_clienti.js', null, $file_ver);
wp_localize_script('admin_clienti', 'bbAdmin_clienti', array(
		    'pluginUrl' => plugins_url().'/book-beach',
		    ));
?>

<div class="wrap-bb full-screen">
	<h3 class="wrap-bb-title">Gestisci i tuoi clienti</h3>

	<section>
		<table id="tabella-clienti" class="display" style="width:100%" data-page-length="<?php echo getCountClienti();?>">
			<thead>
				<tr>
					<th>ID</th>
					<th>Cognome</th>
					<th>Nome</th>
					<th>Telefono</th>
					<th>Operazioni</th>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th>ID</th>
					<th>Cognome</th>
					<th>Nome</th>
					<th>Telefono</th>
					<th>Operazioni</th>
				</tr>
			</tfoot>
		</table>
	</section>

	<script type="text/javascript">

	jQuery(document).ready(function() {
		var json = getJsonClienti();
		jQuery.each(json,function(i,val){
			var prenotazioni = "<button data-modal-id=\"prenotazioni\" data-id=\""+val.id+"\" class=\"prenotazioni\"><i class=\"fa fa-calendar\"></i></button>";
			var modifica = "<button data-id=\""+val.id+"\" class=\"edit\"><i class=\"fa fa-pencil\"></i></button>";
			var salva = "<button data-id=\""+val.id+"\" class=\"salva\"><i class=\"fa fa-save\"></i></button>";
			var elimina = "<button data-id=\""+val.id+"\" class=\"elimina\"><i class=\"fa fa-trash\"></i></button>";
			val.operazioni = prenotazioni + modifica + salva + elimina;
		})


		jQuery('#tabella-clienti').DataTable( {
			"data": json,
			paging: false,
			order: [[1,'asc']],
			info: false,
			scrollY: '65vh',
			scrollCollapse : true,
			"columns": [
				{ "data": "id" },
				{ "data": "cognome" },
				{ "data": "nome" },
				{ "data": "telefono" },
				{ "data": "operazioni" }
	        ],
	        rowCallback: function( row, data ) {
				jQuery('td:eq(4)', row).html( '<b>A</b>' );
			},
			columnDefs: [
				{ "visible": false, "targets": 0 },
				{ "type": "html-input", "targets": [4] },
				{ "width": "190px", "targets": [4] },
			],
			"createdRow": function( row, data, dataIndex ) {
				jQuery(row).attr('id',data.id);
				jQuery(row).find('td').eq(0).addClass('cognome');
				jQuery(row).find('td').eq(1).addClass('nome');
				jQuery(row).find('td').eq(2).addClass('telefono');
				jQuery(row).find('td').eq(3).addClass('operazioni');
			},
			language : {
				
			    "decimal":        "",
			    "emptyTable":     "Nessun dato disponibile",
			    "info":           "Riga da _START_ a _END_ di _TOTAL_ righe",
			    "infoEmpty":      "Riga 0 a 0 di 0 righe",
			    "infoFiltered":   "(filtro per _MAX_ entrate)",
			    "infoPostFix":    "",
			    "thousands":      ",",
			    "lengthMenu":     "Mostra _MENU_ righe",
			    "loadingRecords": "Caricamento...",
			    "processing":     "Caricamento...",
			    "search":         "Cerca:",
			    "zeroRecords":    "Nessun dato disponibile",
			    "paginate": {
			        "first":      "Prima",
			        "last":       "Ultima",
			        "next":       '<i class="fa fa-arrow-right"></i>',
			        "previous":   '<i class="fa fa-arrow-left"></i>'
			    },
			    "aria": {
			        "sortAscending":  ": activate to sort column ascending",
			        "sortDescending": ": activate to sort column descending"
			    }
			
			}

	    } );
	
		<?php if($_GET['id']): ?>
		jQuery('.prenotazioni[data-id=<?php echo $_GET["id"]; ?>]').trigger('click');
		<?php endif; ?>

	} );
	</script>

	<!-- MODAL -->
	<div class="modal" id="prenotazioni">
	    <div class="modal-content">
	        <div class="close"></div>
	        <div class="inner">

	        </div>
	    </div>
	</div>

	<?php include 'menu-buttons.php'; ?>
</div>
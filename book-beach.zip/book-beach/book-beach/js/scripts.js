var plugin_url = bbScripts.pluginUrl;
var startDate = moment().startOf('hour').format('YYYY-MM-DD');
var endDate = moment().startOf('hour').add(48, 'hour').format('YYYY-MM-DD');
var adminPage = bbScripts.adminPage;
var clienti_url = bbScripts.clienti_url;
var singledayDate = null;

var gbl_response = false;

var mesi = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
var giorni = ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];

moment.locale('it',{
	weekdays : giorni
});


/*on load*/
jQuery(document).ready(function(){
	jQuery("table.spiaggia").removeClass('loading');
	/*range date iniziali*/
	jQuery('a[href="#gnext"]').attr('data-value',moment(startDate).add(24,'hour').format('YYYY-MM-DD'));
	jQuery('a[href="#gprev"]').attr('data-value',moment(startDate).add(-24,'hour').format('YYYY-MM-DD'));
	singledayDate = jQuery('#singleday').val();
	aggiornaTabella();
	if(adminPage != 'book_beach_clienti'){
		loadSinglePicker(startDate);
	}
})

/*datepicker singleday*/
function loadSinglePicker(giorno){
	jQuery('#singleday').daterangepicker({
		direction: "ltr",
		locale: {
			format: 'dddd DD/MM/YYYY',
			monthNames: mesi,
			dayNames: giorni,
			daysOfWeek: ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"]
		},
		singleDatePicker: true,
		showDropdowns: false,
		startDate: moment(giorno),
		maxDate: '31/12/'+moment().year(),
		}, function(start, end, label) {
			startDate = start.format('YYYY-MM-DD');
			//var fulldate = jQuery('#singleday').val().split('/');
			//jQuery('#singleday').val(fulldate[0]+' '+mesi[parseInt(fulldate[1],10)-1]+' '+fulldate[2]);
			jQuery('a[href="#gnext"]').attr('data-value',moment(start).add(24,'hour').format('YYYY-MM-DD'));
			jQuery('a[href="#gprev"]').attr('data-value',moment(start).add(-24,'hour').format('YYYY-MM-DD'));
			singledayDate = inverseDate(startDate,'-','/');
			aggiornaTabella();
		//var years = moment().diff(start, 'years');
		//alert("You are " + years + " years old!");
	});
}

/*periodo range picker*/
function loadRangePicker(){
	jQuery('input[name="multiday"]').daterangepicker({
		//timePicker: true,
		autoApply: true,
		linkedCalendars: false,
		minDate: new Date(),
		maxDate: '31/12/'+moment().year(),
		startDate: moment().startOf('hour'),
		endDate: moment().startOf('hour').add(48, 'hour'),
		locale: {
			format: 'DD-MM-YYYY',
			monthNames: mesi,
			daysOfWeek: ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"]
		}
	},
	function(start, end) {
		startDate = start.format('YYYY-MM-DD');
		endDate = end.format('YYYY-MM-DD');
		jQuery('#multiday').attr('data-value',startDate + ',' + endDate);

	});
}loadRangePicker();

jQuery('a[href="#gnext"], a[href="#gprev"]').click(function(){
	var data = jQuery(this).attr('data-value');
	jQuery('#singleday').daterangepicker("destroy");
	loadSinglePicker(data);
	startDate = moment(data).format('YYYY-MM-DD');
	singledayDate = moment(data).format('DD/MM/YYYY');
	jQuery('a[href="#gnext"]').attr('data-value',moment(data).add(24,'hour').format('YYYY-MM-DD'));
	jQuery('a[href="#gprev"]').attr('data-value',moment(data).add(-24,'hour').format('YYYY-MM-DD'));
	//jQuery('#singleday').data('daterangepicker').setStartDate(new Date(data));
	aggiornaTabella();
})
function returnToCurrentDate(){
	var data = moment().startOf('hour');
	jQuery('#singleday').daterangepicker("destroy");
	loadSinglePicker(data);
	startDate = moment(data).format('YYYY-MM-DD');
	singledayDate = moment(data).format('DD/MM/YYYY');
	jQuery('a[href="#gnext"]').attr('data-value',moment(data).add(24,'hour').format('YYYY-MM-DD'));
	jQuery('a[href="#gprev"]').attr('data-value',moment(data).add(-24,'hour').format('YYYY-MM-DD'));
	//jQuery('#singleday').data('daterangepicker').setStartDate(new Date(data));
	aggiornaTabella();
}

function getActiveSection(){
	if( jQuery('#gestione-prezzi #typeday').length > 0 ){
		return jQuery('#typeday .bb-r-item[data-status="active"]').attr('fire-section');
	}
}
function hasLettini(){
	var is_selected = false;
	jQuery.each(jQuery('.place'),function(i,val){
		if(jQuery(this).hasClass('checked')){
			is_selected = true;
		}
	});
	if (!is_selected) {alert('Seleziona almeno una postazione');}
	return is_selected;
}
function hasPrezzo(){
	var prezzo = jQuery('#prezzo').val();
	if(!prezzo){
		alert('Aggiungi un prezzo');
		return false;
	}
	return true;
}

function getLettiniSelezionati(){
	var lettini = [];
	jQuery.each(jQuery('.place'),function(i,val){
		if(jQuery(this).hasClass('checked')){
			lettini.push(jQuery(this).parent().attr('data-id'));
		}
	});
	return lettini;
}

function formatPrice(price){
	return parseFloat(price).toFixed(2)+'€';
}
/*aggiorna tabella*/
function aggiornaTabella(){
	jQuery("table.spiaggia").addClass('loading');
	var data = singledayDate;
	//console.log(data + ' - ' + startDate)
	if(adminPage == 'book_beach_price_setting'){
		var action = 'bb_aggiorna_tabella_prezzi';
	}
	if( adminPage == 'book_beach'){
		var action = 'bb_aggiorna_tabella_prenotazioni';
	}

	jQuery( "table.spiaggia" ).load( 
		//link parser
		plugin_url+"/inc/parser.php", 
		//data
		{ 
			action: action,
			data: data,
			section: getActiveSection()
		},function(){
			//complete function
			jQuery(this).removeClass('loading');
		} 
	);
}

/*radio fire*/
jQuery('.bb-r-item').on('click',function(){
	jQuery.each(jQuery(this).closest('.bb-radio').find('.bb-r-item'),function(i,val){
		jQuery(this).attr('data-status','disabled');
	})
	jQuery(this).attr('data-status','active');
})
/*checkbox fire*/
jQuery(document).on('click','.bb-c-item .icon',function(){
	switch(jQuery(this).parent().attr('data-status')){
		case 'checked':
			jQuery(this).parent().attr('data-status','disabled');
			break;
		case 'disabled':
			jQuery(this).parent().attr('data-status','checked');
			break;
	}
})
/*fire sections*/
jQuery('[fire-section]').click(function(){
	var section = jQuery(this).attr('fire-section');
	var group = jQuery('[data-section="'+section+'"]').attr('data-group');
	if(group){
		jQuery.each(jQuery('[data-group="'+group+'"]'),function(i, val){
			jQuery(this).attr('visibility','off');
		})
	}else{
		jQuery('[data-section="'+section+'"]').attr('visibility','off');
	}
	jQuery('[data-section="'+section+'"]').attr('visibility','on');
})
/* GET PRENOTAZIONE BY GIORNO AND ID POSTAZIONE*/
function getPrenotazione(giorno,id_postazione){
	var json = null;
	jQuery.ajax({
		async : false,
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			giorno: giorno,
			id_postazione: id_postazione,
			action: 'get_prenotazione'
		},
		success  : function(msg){
			json = msg;
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
	return JSON.parse(json);
}
/* GET RIEPILOGO NOTE BY ID CLIENTE*/
function getRiepilogoNote(id_cliente){
	var json = null;
	jQuery.ajax({
		async : false,
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			id_cliente: id_cliente,
			action: 'get_riepilogo_note'
		},
		success  : function(msg){
			json = msg;
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
	return JSON.parse(json);
}
/* GET CLIENTE BY ID*/
function getCliente(id){
	var json = null;
	jQuery.ajax({
		async : false,
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			id: id,
			action: 'get_cliente_by_id'
		},
		success  : function(msg){
			json = msg;
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
	return JSON.parse(json);
}
/* GET CLIENTE BY ID*/
function getPrenotazioniCliente(id){
	var json = null;
	jQuery.ajax({
		async : false,
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			id: id,
			action: 'get_prenotazion_by_id_cliente'
		},
		success  : function(msg){
			json = msg;
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
	return JSON.parse(json);
}
/*modal*/
jQuery(document).on('click','button[data-modal-id]',function(){
	var id = jQuery(this).attr('data-modal-id');
	jQuery('#'+id + '.modal').addClass('visible');
})
jQuery(document).on('click','.modal .close',function(){
	jQuery(this).closest('.modal.visible').removeClass('visible');
})
/*CLEAR MODAL FORM*/
function clearForm(modal){
	jQuery(modal).attr('data-status','');
	jQuery('.postazione').remove();
	jQuery(modal).find('input').val('');
	jQuery(modal).find('#lista-note').remove();
	jQuery(modal).find('#riepilogo-note').text('');
	jQuery(modal).find('#prenotazioni-cliente').text('');
	jQuery(modal).find('#prenotazioni-cliente').attr('href','');
	jQuery(modal).find('textarea').val('');
	jQuery('.bb-r-item').first().trigger('click');
	jQuery('.bb-c-item').attr('data-status','disabled');
	jQuery('#remove-prenotazione').remove();
	jQuery(modal).removeClass('visible');
}
/*SWITCH FULL SCREEN*/
function toggleFullScreen() {
	/*if (document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement) {
	    if (document.cancelFullScreen) {
	        document.cancelFullScreen();
	    } else {
	        if (document.mozCancelFullScreen) {
	            document.mozCancelFullScreen();
	        } else {
	            if (document.webkitCancelFullScreen) {
	                document.webkitCancelFullScreen();
	            }
	        }
	    }
	    jQuery('.wrap-bb').removeClass('full-screen');
	} else {
	    const _element = document.documentElement;
	    if (_element.requestFullscreen) {
	        _element.requestFullscreen();
	    } else {
	        if (_element.mozRequestFullScreen) {
	            _element.mozRequestFullScreen();
	        } else {
	            if (_element.webkitRequestFullscreen) {
	                _element.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
	            }
	        }
	    }
	    jQuery('.wrap-bb').addClass('full-screen');
	}*/
	jQuery('.wrap-bb').toggleClass('full-screen');
}

// Returns an array of dates between the two dates
var getDateArray = function(start, end) {
    var arr = new Array();
    var dt = new Date(start);
    while (dt <= end) {
    	var D = new Date(dt).getDate();
    	D = (D < 10) ? '0'+D : D;
    	var M = new Date(dt).getMonth()+1;
    	M = (M < 10) ? '0'+M : M;
    	arr.push(new Date(dt).getFullYear()+'-'+M+'-'+D);
        dt.setDate(dt.getDate() + 1);
    }
    return arr;
}
/*get global date*/
function getRangeDates(range) {
	/*05-03-2019 - 07-03-2019*/
	var period = range.split(' - ');
	return getDateArray(new Date(inverseDate(period[0])), new Date(inverseDate(period[1])));
}

function inverseDate(data,prevSep,nextSep){
	// d-m-y to y-m-d
	prevSep = (prevSep) ? prevSep : '-';
	nextSep = (nextSep) ? nextSep : '-';
	var d = data.split(prevSep);
	return d[2] + nextSep + d[1] + nextSep + d[0];
}

/*get place status*/
function getPlaceStatus(place){
	var out = '';
	jQuery.each(JSON.parse(bbScripts.feed), function(i, val){
		if(val.id == place){
			out = val.status;
		}
	})
	return out;
}

/*cancella prenotazione*/
function cancellaPrenotazione(id){
	gbl_response = false;
	if( confirm("Sei sicuro di voler cancellare la prenotazione?") ){
		jQuery.ajax({
			type: "POST",
			async: false,
			url: plugin_url+"/inc/parser.php",
			data: {
				id: id,
				action: 'cancella_prenotazione'
			},
			success  : function(msg){
				gbl_response = true;
				alert('Prenotazione cancellata!');
			} ,
			error    : function(msg) { 
				alert("Fallito");
				gbl_response = false;
			} 
		});
	}
}

/*trigger change period su prenotazione*/
function populatePeriod(){
	jQuery("#selezione-lettini").addClass('loading');

	jQuery( "#selezione-lettini" ).load( 
		//link parser
		plugin_url+"/inc/parser.php", 
		//data
		{ 
			action: 'get_occupato_in_periodo',
			range: getRangeDates(jQuery('#dettagli-prenotazione-periodo #multiday').val()),

		},function(){
			//complete function
			jQuery(this).removeClass('loading');
		} 
	);
}
jQuery('#dettagli-prenotazione-periodo #multiday').on('change',function(){
	populatePeriod();
})

//importo suggerito
function updateImportoSuggerito(type){

	switch(type){
		case 'single':
			var data = jQuery('#data-selezionata').text();
			var postazioni = jQuery('#postazione-selezionata').text().split(',');
			break;
		case 'period':
			var data = jQuery('#multiday').val();
			var pos = [];
			var count = 0;
			jQuery.each(jQuery('#selezione-lettini .bb-c-item'),function(i,val){
				if( jQuery(this).attr('data-status') == 'checked' ){
					pos[count] = jQuery(this).attr('data-value').trim();
					count++;
				}
			})
			var postazioni = JSON.stringify(pos);
			break;
	}

	jQuery.ajax({
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			type: type,
			data: data,
			postazioni: postazioni,
			action: 'update_importo_suggerito'
		},
		success  : function(msg){
			if(msg){
				jQuery('#importo-suggerito span').text(msg + ' €');
			}else{
				jQuery('#importo-suggerito span').text('0 €');
			}
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});

}

//aggiorna prenotazione
function aggiornaPrenotazione(id,giorno,postazione,importo,pagamento){
	jQuery.ajax({
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		//async: false,
		data: {
			id: id,
			giorno: giorno,
			postazione: postazione,
			importo: importo,
			pagamento: pagamento,
			action: 'aggiorna_prenotazione'
		},
		success  : function(msg){
			console.log(msg);
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
}

//aggiorna presenza
function aggiornaPresenza(prenotazione, val){
	var el = jQuery('[data-prenotazione="'+prenotazione+'"]');
	jQuery.ajax({
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			id: prenotazione,
			val: val,
			action: 'aggiorna_postazione'
		},
		success  : function(msg){
			jQuery(el).find('.presenza input').css('background','#add6ad');
			setTimeout(function(){
				jQuery(el).find('.presenza input').css('background','white')
			},700);
		} ,
		error    : function(msg) { 
			alert("Presenza nella postazione " + id + " non inserita. Aggiorna la pagina e riprova"); 
		} 
	});
}

jQuery(document).on('click','.presenza input',function(){
	var prenotazione = jQuery(this).closest('td').attr('data-prenotazione');
	var val = ( jQuery(this).prop('checked') == true ) ? 1 : 0;
	aggiornaPresenza(prenotazione,val);
})
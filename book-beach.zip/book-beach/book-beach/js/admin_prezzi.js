var plugin_url = bbAdmin_prezzi.pluginUrl;
var startDate = moment().startOf('hour').format('YYYY-MM-DD');

/*checked */
jQuery('.spiaggia').on('click','.place',function(){
	if(jQuery(this).hasClass('checked')){
		jQuery(this).removeClass('checked');
	}else{
		jQuery(this).addClass('checked');
	}
})

/*seleziona / deseleziona tutto */
jQuery('#seleziona-tutto').click(function(){
	jQuery('.place').addClass('checked');
})
jQuery('#deseleziona-tutto').click(function(){
	jQuery('.place').removeClass('checked');
})

/*correggi valore prezzo*/
jQuery('#prezzo').on('change keydown keyup paste',function(){
	jQuery(this).val( jQuery(this).val().replace(',','.') );
});

/*aggiorna tabella*/

jQuery('#typeday .bb-r-item').on('click', function(){
	if(getActiveSection() == 'singleday'){
		jQuery('#prev-next-day').show();
	}else{
		jQuery('#prev-next-day').hide();
	}
	aggiornaTabella();
});

/*genera json*/
function JsonForUpdate(date){
	var prezzo = jQuery('#prezzo').val();
	var json = '';

	jQuery.each(date,function(i,data){
		//json += JsonForUpdate(val) + ',';
		jQuery.each(jQuery('.place'),function(j,val){
			var id = jQuery(this).closest('td').attr('data-id');

			if(jQuery(this).hasClass('checked')){
				//'{id:{data:2019-02-01,prezzo:35.5}}'
				json += '{"id":"'+id+'","data":"'+data+'","prezzo":'+prezzo+'},';
			}
		});
	});

	json = json.slice(0,json.length-1);
	return '['+json+']';
}
/*click aggiorna prezzo*/
jQuery('#set-prezzo').on('click',function(){
	var date = [];
	if(hasLettini() && hasPrezzo()){
		switch( getActiveSection() ){
			case 'singleday':
				var d = jQuery('#singleday').val().split('/');
				date = [d[2] + '-' + d[1] + '-' + d[0]];
				break;
			case 'multiday':
				//get array of date
				date = getRangeDates(jQuery('#multiday').val());
				break;
		}
		var json = JsonForUpdate(date);
		if( confirm("Sei sicuro di voler aggiornare i prezzi?") ){
			aggiornaPrezzo(json);
		}
	}
});
/*ajax per aggiornamento prezzi*/
function aggiornaPrezzo(json){
	jQuery("table.spiaggia").addClass('loading');
	jQuery.ajax({
		url: plugin_url+"/inc/parser.php",
		type: "POST",

		data: {
			data:JSON.parse(json),
			action: 'update_bb_prices'
		},
		success  : function(msg){
			jQuery("table.spiaggia").removeClass('loading');
			alert(msg);
			aggiornaTabella();
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
}
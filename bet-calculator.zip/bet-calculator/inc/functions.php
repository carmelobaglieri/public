<?php

if( is_user_logged_in() ){
	add_action( 'wp_ajax_get_sports', 'get_sports_func');
	add_action( 'wp_ajax_get_odds', 'get_odds_func');
}else{
	add_action( 'wp_ajax_nopriv_get_sports', 'get_sports_func');
	add_action( 'wp_ajax_nopriv_get_odds', 'get_odds_func');
}

function get_sports_func(){
	/*$apikey = get_option('odds_calc_api_key');

	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://odds.p.rapidapi.com/v1/sports",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
			"x-rapidapi-host: odds.p.rapidapi.com",
			"x-rapidapi-key: {$apikey}"
		),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		echo "cURL Error #:" . $err;
	} else {
		echo $response;
	}
	file_put_contents('sports.json', $response, FILE_USE_INCLUDE_PATH);*/
	echo get_option('odds_calc_sports');

    wp_die();
};


function get_odds_func(){
	/*echo file_get_contents("odds.json");
	wp_die();
	*/
	$apikey = get_option('odds_calc_api_key');
	
	if($apikey){
		$sport = $_POST['sport'];
		$region = $_POST['region'];
		$mkt = $_POST['mkt'];

		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => "https://odds.p.rapidapi.com/v1/odds?sport={$sport}&region={$region}&mkt={$mkt}",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
				"x-rapidapi-host: odds.p.rapidapi.com",
				"x-rapidapi-key: {$apikey}"
			),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			echo $response;
		}
	}

    wp_die();
};
var calculatorClass = function(options){

	var vars = {
		format: '',
	};

	var root = this;

	this.construct = function(options){
        jQuery.extend(vars , options);
    };

    this.setFormat = function(val){
    	vars.format = val;
    	return;
    }

    this.getFormat = function(){
    	return vars.format;
    }

    this.clone = function(){
    	var el = jQuery('.all-odds input').first().clone();
		jQuery(el).val('');
		jQuery('.all-odds').append(el);
    }

	this.formatNumber = function(el, type){
		if( type == 'stake'){
			return (el) ? parseFloat(el).toFixed(2) : '';
		}else{
			switch( jQuery('#odds-format').val() ){
				case 'decimal':
					return (el) ? parseFloat(el).toFixed(3) : '';
				case 'american':
					return (el) ? parseInt(el) : '';
				case 'fractal':
					return el;
			}
		}
	}

	this.validate = function (e, type){
		var permitted = ["0","1","2","3","4","5","6","7","8","9"];
		if( type == 'odd'){
			switch( vars.format ){
				case 'decimal':
					permitted.push(".");
					break;
				case 'american':
					permitted.push("-");
					break;
				case 'fractal':
					permitted.push("/");
					break;
			}
		}else{
			permitted.push(".");
		}
		if( jQuery.inArray(e.key, permitted) !== -1 ){
			return;
		}
		e.preventDefault();
	}

	this.calcPayout = function(){
		var tot = 1;
		jQuery.each( jQuery(document).find('#odds-stake, .all-odds input'), function(i, el){
			tot *= (jQuery(el).val()) ? root.convertFormat( jQuery(el).val(), vars.format, 'decimal' ) : 1;
		})
		tot = (!jQuery(document).find('#odds-stake').val()) ? 0 : tot;
		tot = ( tot == undefined ) ? 0 : tot;
		jQuery('#payout').val('$'+tot.toFixed(2));
	}

	this.reset = function(){
		vars = {
			format: jQuery('#odds-format').val()
		};
		jQuery('#odds-format').val(jQuery('#odds-format option:first').val());
		jQuery('#odds-stake').val('');
		jQuery('.all-odds input').val('');
		jQuery('.all-odds input').not(':first-child').remove();
		jQuery('#payout').val('$0.0');
	}

	this.convertFormat = function( val, from, to ){
		if(from == to){
			return val;
		}
		var calc, res = null;
		/* dec > US*/
		if( from == 'decimal' && to == 'american' ){
			if( val >= 2.000 ){
				calc = ((val - 1) * 100);
			}else{
				calc = ( -100 / (val - 1));
			}
			res = calc.toFixed(0);
		}/* US > dec*/
		else if( from == 'american' && to == 'decimal' ){
			if( val >= 0 ){
				calc = ((val/100)+1);
			}else{
				calc = ((-100/val)+1);
			}
			res = calc.toFixed(3);
		}/* dec > frac */
		else if( from == 'decimal' && to == 'fractal' ){		
			calc = val - 1;
			var countDec = countDecimals(calc);
			var numerator = calc * Math.pow(10, countDec);
			var denominator = Math.pow(10, countDec);
			calc = reduce(numerator, denominator);
			res = calc[0] + '/' + calc[1];
		}/* frac > dec */
		else if( from == 'fractal' && to == 'decimal' ){
						
			calc = (val.split('/')[0]) / (val.split('/')[1]) + 1;
			res = calc.toFixed(3);
		}
		/* frac > US && US > frac */
		else{
			res = root.convertFormat( root.convertFormat( val, from,'decimal' ), 'decimal', to);
		}
		return res;
	}

	this.updateOddsFormat = function(){
		var new_format = jQuery('#odds-format').val();
		jQuery.each( jQuery(document).find('.all-odds input'), function(i, el){
			jQuery(this).val( root.convertFormat( jQuery(el).val(), vars.format, new_format ) );
		});
		vars.format = new_format;
		return;
	}

	var countDecimals = function (num) {
	    if(Math.floor(num.valueOf()) === num.valueOf()) return 0;
	    return num.toString().split(".")[1].length || 0; 
	}

	var reduce = function(numerator,denominator){
		var gcd = function gcd(a,b){
			return b ? gcd(b, a%b) : a;
		};
		gcd = gcd(numerator,denominator);
		return [numerator/gcd, denominator/gcd];
	}

	this.construct(options);

}

var calculator = new calculatorClass({ 
	format : jQuery('#odds-format').val() 
});
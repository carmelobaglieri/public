<?php
function bbCreateRole(){
    global $wp_roles;
    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();

    $us = $wp_roles->get_role('subscriber');
    $us->add_cap( 'manage_options' );
    //Adding a 'new_role' with all admin caps
    $wp_roles->add_role('booking_manager', 'Booking Manager', $us->capabilities);
}
function checkBbPlaceStatus($data,$id_pos){
	if($data){
		foreach (json_decode($data) as $key) {
			if($key->id == $id_pos)
				return $key->status;
		}
	}
	return 'active';
}
function check_status_by_date_lettino($data, $lettino){
	global $wpdb;
	$prefix = $wpdb->prefix;
	$results = $wpdb->get_results("SELECT * FROM {$prefix}prenotazioni_bb WHERE giorno = '{$data}' AND lettino LIKE '{$lettino}'");

	switch (count($results)) {
		case 0:
			return 'active';
		case 2:
		case 3:
			return 'g-intera';
		default:
			return $results[0]->stato;
	}
}
function update_singleday_booking_results($data){
	$righe = esc_attr( get_option('bb_righe') );
	$colonne = esc_attr( get_option('bb_colonne') );
	$feed = get_option('bb_feed');

	$html .= '<table class="spiaggia loading">';
	for ($i=1; $i < $righe+1; $i++) { 
		$html .= '<tr>';
		for ($j=1; $j < $colonne+1; $j++) { 

			$status = check_status_by_date_lettino($data,$i.'-'.$j);
			$active = checkBbPlaceStatus($feed,$i.'-'.$j);

			if($active == 'active'){
	    		$html .= '<td data-id="'.$i.'-'.$j.'" data-status="'.$status.'"><div class="place"><label>'.$i.'-'.$j.'</label></div></td>';
			}else{
				$html .= '<td data-id="'.$i.'-'.$j.'"></td>';
			}
    	}
    	$html .= '</tr>';
	}
	$html .= '</table>';
	return $html;
}

function getBbData(){
	return json_decode(get_option('bb_feed'));
}
/*modulo ricerca*/
function BbSearchForm(){
	$html .= '
	<div id="bb-form-booking">
		<div class="bb-row">
			<div class="bb-col-4 padding10 bb-claim">
				<strong>Quando vorresti rilassarti?</strong>
				<!--div id="typeday" class="bb-radio">
					<div class="bb-r-item" data-status="active" fire-section="singleday">
						<span class="icon"></span> Giorno Singolo
					</div>
					<div class="bb-r-item" data-status="disabled" fire-section="multiday">
						<span class="icon"></span> Più giorni
					</div>
				</div-->
			</div>
			<div class="bb-col-4">
				<div class="" visibility="on" data-group="search-form" data-section="singleday">
					<input autocomplete="off" class="bb-input" type="text" name="singleday" value="'.date('d/m/Y').'" id="singleday" />
				</div>
				<div class="" visibility="off" data-group="search-form" data-section="multiday">
					<input autocomplete="off" class="bb-input" type="text" name="multiday" id="multiday" />
				</div>
			</div>
			<div class="bb-col-4">
				<button id="check-bb-dispo" class="bb-submit">Verifica disponibilità</button>
			</div>
		</div>
	</div>';
	return $html;
}
/*riepilogo prenotazione*/
function BbRiepilogo(){
	$html .= '
	<div id="bb-riepilogo">
		<table>
			<thead>
				<tr>
					<th>Lettini selezionati</th>
					<th>Tipologia prenotazione</th>
					<th>Data prenotazione</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
		<div class="bb-row">
			<div class="bb-col-4">&nbsp;</div>
			<div class="bb-col-4">&nbsp;</div>
			<div class="bb-col-4">
				<button id="bb-continua" class="bb-submit">Continua</button>
			</div>
		</div>
	</div>
	';
	return $html;
}

function getPrezzoByDataeLettino($data,$lettino){
	global $wpdb;
	$prezzi_bb = $wpdb->prefix . "prezzi_bb"; 
	$results = $wpdb->get_results("SELECT prezzo FROM $prezzi_bb WHERE giorno = '$data' AND lettino='$lettino'");
	return ($results[0]->prezzo) ? $results[0]->prezzo : '';
}

function setCliente($cognome, $nome, $telefono){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb";
	$wpdb->insert( 
		$clienti_bb, 
		array( 
			'cognome' => $cognome, 
			'nome' => $nome ,
			'telefono' => $telefono ,
		), 
		array( 
			'%s', 
			'%s', 
			'%s', 
		) 
	);
	return $wpdb->insert_id;
}
function getCountClienti(){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb";
	$results = $wpdb->get_var("SELECT COUNT(id) FROM $clienti_bb");
	return $results;
}
function aggiornaCliente($id, $cognome, $nome, $telefono){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb";
	$wpdb->update( 
		$clienti_bb, 
		array( 
			'cognome' => $cognome, 
			'nome' => $nome ,
			'telefono' => $telefono ,
		), 
		array( 
			'id' => $id
		),
		array(
			'%s', 
			'%s', 
			'%s', 
		)
	);
	return $wpdb->insert_id;
}
function eliminaCliente($id){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb";
	$wpdb->delete( $clienti_bb, array( 'id' => $id ) );
}

function getClienteByData($cognome, $nome, $telefono){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb"; 
	$results = $wpdb->get_results("SELECT id FROM $clienti_bb WHERE cognome = '$cognome' AND nome='$nome' AND telefono='$telefono'");
	return ($results[0]->id) ? $results[0]->id : '';
}
function getClienteByID($id = null){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb";
	$results = $wpdb->get_results("SELECT * FROM $clienti_bb WHERE id=$id");
	return ($results[0]) ? $results[0] : '';
}
function getClienti(){
	global $wpdb;
	$clienti_bb = $wpdb->prefix . "clienti_bb";
	$results = $wpdb->get_results("SELECT * FROM $clienti_bb group by cognome,nome,telefono");
	return ($results) ? json_encode($results) : '';
}
function getInfoByData($giorno,$postazione){
	global $wpdb;
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb"; 
	$results = $wpdb->get_results("SELECT * FROM $prenotazioni_bb WHERE giorno = '$giorno' AND postazione='$postazione'");
	return ($results[0]) ? $results[0] : '';
}
function checkAbbonamento($id_cliente,$giorno){
	$data = new DateTime($giorno);
	$ieri = $data->modify( '-1 day' )->format('Y-m-d');
	$oggi = $data->modify( '+1 day' )->format('Y-m-d');
	$domani = $data->modify( '+1 day' )->format('Y-m-d');

	global $wpdb;
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb";

	$query = $wpdb->get_results("SELECT * FROM $prenotazioni_bb WHERE (giorno = '$ieri' OR giorno = '$giorno' OR giorno = '$domani') AND id_cliente= $id_cliente ");
	
	if(count($query) > 1)
		return true;
	else
		return false;
}
function getPrenotazione($giorno,$postazione){
	global $wpdb;
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb";
	$results = $wpdb->get_results("SELECT * FROM $prenotazioni_bb WHERE giorno = '$giorno' AND postazione='$postazione'");
	return ($results[0]) ? $results[0] : '';
}

function getNoteByIdCliente($id){
	global $wpdb;
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb";
	$results = $wpdb->get_results("SELECT giorno, postazione, note, pagamento, importo FROM $prenotazioni_bb WHERE id_cliente = $id");
	return ($results) ? $results : '';
}

function clientiDaChiamare(){
	global $wpdb;
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb";
	$sql = $wpdb->get_results("SELECT id_cliente FROM $prenotazioni_bb WHERE giorno = (CURRENT_DATE) GROUP BY id_cliente");
	$oggi = array();
	foreach ($sql as $key) {
		array_push($oggi, $key->id_cliente);
	}
	$sql = $wpdb->get_results("SELECT id_cliente FROM $prenotazioni_bb WHERE giorno = (CURRENT_DATE + INTERVAL 1 DAY) GROUP BY id_cliente");
	$domani = array();
	foreach ($sql as $key) {
		array_push($domani, $key->id_cliente);
	}
	foreach ($domani as $id) {
		if(!in_array($id, $oggi)){
			$cliente = getClienteByID($id);
			$html .= '<b>'.$cliente->cognome . ' '. $cliente->nome . '</b> '. $cliente->telefono .'<br>';
		}
	}
	return ($html) ? '<h4 style="margin: 10px 0 0;text-decoration: underline;">Clienti da chiamare</h4>'.$html : '';
}
function isOccupatoInPeriodo($range, $postazione){
	foreach ($range as $giorno) {
		if( getInfoByData($giorno,$postazione) ){
			return true;
		}
	}
	return false;
}

?>
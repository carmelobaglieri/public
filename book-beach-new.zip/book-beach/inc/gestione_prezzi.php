<?php
global $file_ver;
?>
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/daterangepicker.css' );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/fonts/fontawesome/font-awesome.min.css' );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/book-beach/css/general.css?ver=<?php echo $file_ver;?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/book-beach/css/admin_prezzi.css">
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/moment.min.js' );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/daterangepicker.min.js' );?>"></script>

<?php
	wp_enqueue_script('scripts', plugins_url() . '/book-beach/js/scripts.js', null, $file_ver);
    wp_localize_script('scripts', 'bbScripts', array(
            'pluginsUrl' => plugins_url().'/book-beach',
            'adminPage' => $_GET['page'],
            ));
	wp_enqueue_script('admin_prezzi', plugins_url() . '/book-beach/js/admin_prezzi.js', null, $file_ver);
	wp_localize_script('admin_prezzi', 'bbAdmin_prezzi', array(
		    'pluginUrl' => plugins_url().'/book-beach',
		    ));

	$righe = esc_attr( get_option('bb_righe') );
	$colonne = esc_attr( get_option('bb_colonne') );
	$feed = get_option('bb_feed');
?>

<div class="wrap-bb full-screen">
	<h3 class="wrap-bb-title">Seleziona un Giorno o un Periodo e Mostra i prezzi</h3>
	<p><i>Seleziona i lettini a cui vuoi modificare il prezzo, definisci un valore e clicca su <b>Imposta prezzo</b>.</i></p>
	<div id="gestione-prezzi">
		<div id="bb-form-booking" class="space-bottom">
			<div class="bb-row">
				<div class="bb-col-3 padding10 bb-claim">
					<!--strong>Quando vorresti rilassarti?</strong-->
					<div id="typeday" class="bb-radio">
						<div class="bb-r-item" data-status="active" fire-section="singleday">
							<span class="icon"></span> Giorno
						</div>
						<div class="bb-r-item" data-status="disabled" fire-section="multiday">
							<span class="icon"></span> Periodo
						</div>
					</div>
				</div>
				<div class="bb-col-5">
					<div class="bb-row" visibility="on" data-group="search-form" data-section="singleday">
						<div class="bb-col-12">
							<input autocomplete="off" class="bb-input" type="text" name="singleday" value="<?php echo date('d/m/Y'); ?>" id="singleday" />
						</div>
					</div>
					<div class="bb-row" visibility="off" data-group="search-form" data-section="multiday">
						<div class="bb-col-12">
							<input autocomplete="off" class="bb-input" type="text" name="multiday" id="multiday" data-value="" />
						</div>
					</div>
				</div>
				<div class="bb-col-4">
					<p id="prev-next-day"><a href="#gprev"><span class="text-as-icon">&#60;&#60;</span> GG prima</a> <a href="#gnext">GG dopo <span class="text-as-icon">&#62;&#62;</span></a></p>
				</div>
			</div>
		</div>
		<div class="block space-bottom">
			<div class="bb-row">
				<div class="bb-col-12">
					<div class="scrollable">
					<?php
						$html .= '<table class="spiaggia loading">';
						for ($i=1; $i < $righe+1; $i++) { 
							$html .= '<tr>';
							for ($j=1; $j < $colonne+1; $j++) { 

								$active = checkBbPlaceStatus($feed,$i.'-'.$j);

								if($active == 'active'){
						    		$html .= '<td data-id="'.$i.'-'.$j.'"><div class="place"><label>'.$i.'-'.$j.'</label><span class="price"></span></div></td>';
								}else{
									$html .= '<td data-id="'.$i.'-'.$j.'"></td>';
								}
					    	}
					    	$html .= '</tr>';
						}
						$html .= '</table>';
						echo $html;
					?>
					</div>
				</div>

				<div class="bb-col-12" style="margin-top:15px;">
					<p style="margin-bottom:0">
						<a href="#" class="bb-btn" id="seleziona-tutto">Seleziona tutto</a> <a class="bb-btn" href="#" id="deseleziona-tutto">Deseleziona tutto</a>
					</p>
				</div>
			</div>
		</div>

		<div id="controller-prezzi" class="bb-row">
			<div class="bb-col-6">
				<div class="bb-row">
					<div class="bb-col-6">
						<input autocomplete="off" class="bb-input" type="text" name="prezzo" id="prezzo" />
					</div>
					<div class="bb-col-6">
						<button id="set-prezzo" class="bb-submit">Imposta prezzo</button>
					</div>
				</div>
			</div>
			<div class="bb-col-6">
				<?php include 'menu-buttons.php'; ?>
			</div>
		</div>

	</div>
</div>
<script type="text/javascript">

</script>

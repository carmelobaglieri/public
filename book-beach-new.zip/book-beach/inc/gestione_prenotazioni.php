<?php
global $file_ver;
?>
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/jquery-ui.min.css' );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/daterangepicker.css' );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/fonts/fontawesome/font-awesome.min.css' );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/book-beach/css/general.css?ver=<?php echo $file_ver;?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/book-beach/css/admin_prenotazioni.css?ver=<?php echo $file_ver;?>">
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/moment.min.js' );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/jquery-ui.min.js' );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/datepicker-it.js' );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/daterangepicker.min.js' );?>"></script>

<?php
    wp_enqueue_script('scripts', plugins_url() . '/book-beach/js/scripts.js', null, $file_ver);
    wp_localize_script('scripts', 'bbScripts', array(
            'pluginsUrl' => plugins_url().'/book-beach',
            'adminPage' => $_GET['page'],
            'feed'  => get_option('bb_feed'),
            'righe' => esc_attr( get_option('bb_righe') ),
            'colonne' => esc_attr( get_option('bb_colonne') ),
            'clienti_url' => get_home_url() . '/wp-admin/admin.php?page=book_beach_clienti'
            ));
    wp_enqueue_script('admin_prenotazioni', plugins_url() . '/book-beach/js/admin_prenotazioni.js', null, $file_ver);
    wp_localize_script('admin_prenotazioni', 'bbAdmin_prenotazioni', array(
            'pluginUrl' => plugins_url().'/book-beach',
            'clienti_url' => get_home_url() . '/wp-admin/admin.php?page=book_beach_clienti'
            ));

    $righe = esc_attr( get_option('bb_righe') );
    $colonne = esc_attr( get_option('bb_colonne') );
    $feed = get_option('bb_feed');
?>
<style type="text/css">
.spiaggia td{width: calc(100% / <?php echo $colonne;?>)}
</style>

<div class="wrap-bb full-screen">
    <div id="riepilogo">
        <h2 class="pointer" style="margin-top:0;color:#de0000;margin-bottom: 5px;display:inline-block;" onclick="returnToCurrentDate();">Data corrente: <?php echo ucfirst(date_i18n( 'l j F Y', time(), $gmt )); ?></h2>
        <section>
            <div id="clientidachiamare">
                <?php echo clientiDaChiamare();?>
            </div>
        </section>
    </div>
    <div id="gestione-prenotazioni">
        <div id="bb-form-booking" class="space-bottom">
            <div class="bb-row">
                <div class="bb-col-4 bb-col-md-6 bb-col-sm-12 bb-claim">
                    <p id="prev-next-day"><a href="#gprev"><span class="text-as-icon">&#60;&#60;</span> GG prima</a> <a href="#gnext">GG dopo <span class="text-as-icon">&#62;&#62;</span></a></p>
                    </div>
                <div class="bb-col-3 bb-col-md-6 bb-col-sm-12 has_col_inner">
                    <div class="bb-row" visibility="on" data-group="search-form" data-section="singleday">
                        <div class="bb-col-12">
                            <?php
                            $sel_date = ($_GET['date']) ? date( 'd/m/Y', strtotime($_GET['date']) ) : date('d/m/Y');
                            ?>
                            <input autocomplete="off" class="bb-input" type="text" name="singleday" value="<?php echo $sel_date; ?>" id="singleday" readonly />
                        </div>
                    </div>
                </div>
                <div class="bb-col-5 bb-col-md-12 bb-col-sm-12 has_col_inner">
                    <div class="bb-row">
                        <div class="bb-col-6">
                            <button id="add-period-order" class="bb-submit"><span class="text-as-icon">+</span> PRENOTAZ. PERIODO</button>
                        </div>
                        <div class="bb-col-6">
                            <button style="display:none" id="add-single-order" class="bb-submit blue">CONTINUA <span class="text-as-icon">&#62;&#62;</span></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="block space-bottom">
            <div class="bb-row">
                <div class="bb-col-12">
                    <div class="scrollable">
                        <table class="spiaggia loading"></table>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php include 'menu-buttons.php'; ?>
</div>
<!-- MODAL -->
<div id="modal-form" data-status="">
    <div class="modal-content">
        <div class="close"></div>
        <div class="inner">
            <h2 class="head">Inserisci dati prenotazione</h2>

            <div id="dettagli-prenotazione-singola">
                <h3 class="label-section">Dettagli prenotazione</h3>
                <div class="bb-row">
                    <div class="bb-col-12">
                        <b>Data:</b> <span id="data-selezionata"></span><br>
                        <b>Postazione:</b> <span id="postazione-selezionata"></span>
                    </div>
                </div>
            </div>

            <div id="dettagli-prenotazione-periodo">
                <h3 class="label-section">Dettagli prenotazione</h3>
                <div class="bb-row">
                    <div class="bb-col-12">
                        <h4 style="margin: 0 0 5px;">Periodo:</h4>
                        <input autocomplete="off" class="bb-input" type="text" name="multiday" id="multiday" data-value="" readonly />
                    </div>
                </div>
                <div class="bb-row">
                    <div class="bb-col-12">
                        <h4 style="margin: 10px 0 5px;">Postazione:</h4>
                        <div id="tooltip-date-occupate">
                            <input id="calendar-date-occupate" type="text" style="height: 0;padding: 0;margin: 0;border: 0;">
                        </div>
                        <div id="selezione-lettini" class="bb-checkbox"></div>
                    </div>
                </div>
            </div>

            <h3 class="label-section">Dati cliente <a href="" target="_blank" class="as-link" id="prenotazioni-cliente"></a></h3>
            <div class="bb-row">
                <div class="bb-col-4">
                    <input class="bb-input" type="text" id="cognome" placeholder="Cognome*" autocomplete="off">
                </div>
                <div class="bb-col-4">
                    <input class="bb-input" type="text" id="nome" placeholder="Nome*" autocomplete="off">
                </div>
                <div class="bb-col-4">
                    <input class="bb-input" type="tel" id="telefono" placeholder="Telefono*" autocomplete="off">
                </div>
            </div>

            <h3 class="label-section">Note <span class="as-link" id="riepilogo-note"></span></h3>
            <div class="bb-row">
                <div class="bb-col-12">
                    <textarea class="bb-input" id="note" placeholder="Note" rows="5" style="font-size:17px"></textarea>
                </div>
            </div>
            <div class="bb-row">
                <div class="bb-col-8">
                    <h3 class="label-section">Pagamenti</h3>
                    <div class="bb-row">
                        <div class="bb-col-6">
                            <div id="typepay" class="bb-radio">
                                <div class="bb-r-item" data-status="active" data-value="Acconto">
                                    <span class="icon"></span> Acconto
                                </div>
                                <div class="bb-r-item" data-status="disabled" data-value="Pagato">
                                    <span class="icon"></span> Pagato
                                </div>
                            </div>
                        </div>
                        <div class="bb-col-6" style="position:relative;">
                            <input class="bb-input align-center" type="text" id="importo" placeholder="Importo" autocomplete="off">
                            <div id="importo-suggerito">Suggerito: <span></span></div>
                        </div>
                    </div>
                </div>
                <div class="bb-col-4">
                    <h3 class="label-section">Giornata</h3>
                    <div id="giornata" class="bb-checkbox">
                        <div class="bb-c-item" data-status="disabled" data-value="Mezza giornata">
                            <span class="icon"></span> Mezza giornata
                        </div>
                    </div>
                </div>
            </div>

            <h3 class="label-section">Servizi</h3>
            <div class="bb-row">
                <div class="bb-col-12">
                    <div id="servizi" class="bb-checkbox">
                        <div class="bb-c-item" data-status="disabled" data-value="Kit">
                            <span class="icon"></span> Kit
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <div class="bb-row">
                    <div class="bb-col-12">
                        <button class="bb-btn green" id="add-prenotazione">Salva prenotazione</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
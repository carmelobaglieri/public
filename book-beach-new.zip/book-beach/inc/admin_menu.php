<?php

function register_book_beach_menu_page() {
    add_menu_page( 
		'Book Beach',
		'Book Beach',
		'manage_options',
		'book_beach',
		'book_beach_admin_page',
		'',
		6
	);
	add_submenu_page( 
		'book_beach',
		'Gestione prezzi',
		'Gestione prezzi',
		'manage_options',
		'book_beach_price_setting',
		'book_beach_price_setting_page'
		);
	add_submenu_page( 
		'book_beach',
		'Rubrica Clienti',
		'Rubrica Clienti',
		'manage_options',
		'book_beach_clienti',
		'book_beach_clienti_page'
		);
	add_submenu_page( 
		'book_beach',
		'Impostazioni',
		'Impostazioni',
		'manage_options',
		'book_beach_setting',
		'book_beach_setting_page'
		);
}
add_action( 'admin_menu', 'register_book_beach_menu_page' );

add_action('admin_head', 'bb_admin_head_func');
function bb_admin_head_func(){
?>
<style type="text/css">
.menu-top.toplevel_page_book_beach .dashicons-before:before {
    content: '';
    background-image: url('<?php echo plugins_url(); ?>/book-beach/images/icon.svg');
	background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
}
.menu-top.toplevel_page_book_beach:hover .dashicons-before:before{
	background-image: url('<?php echo plugins_url(); ?>/book-beach/images/icon-hover.svg');
}
</style>
<?php
}

function book_beach_admin_page(){
	require 'gestione_prenotazioni.php';
}
function book_beach_setting_page(){
	require 'impostazioni.php';
}
function book_beach_price_setting_page(){
	require 'gestione_prezzi.php';
}
function book_beach_clienti_page(){
	require 'gestione_clienti.php';
}
?>
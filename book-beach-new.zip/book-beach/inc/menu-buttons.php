<div class="menu-buttons">
	<?php if( $_GET['page'] != 'book_beach_price_setting' ){ ?>
		<a id="" href="<?php echo get_home_url(); ?>/wp-admin/admin.php?page=book_beach_price_setting">
	    	<i class="fa fa-euro"></i> Prezzi
	    </a>
    <?php } ?>
    <?php if( $_GET['page'] != 'book_beach' ){ ?>
    <a id="" href="<?php echo get_home_url(); ?>/wp-admin/admin.php?page=book_beach">
        <i class="fa fa-calendar"></i> Prenotazioni
    </a>
    <?php } ?>
    <?php if( $_GET['page'] != 'book_beach_clienti' ){ ?>
    <a id="" href="<?php echo get_home_url(); ?>/wp-admin/admin.php?page=book_beach_clienti">
        <i class="fa fa-users"></i> Clienti
    </a>
    <?php } ?>
    <a id="full-screen" href="#" onclick="toggleFullScreen();">
    	<i class="fa fa-expand"></i>
    </a>
    <a id="tools" href="<?php echo get_home_url(); ?>/wp-admin/admin.php?page=book_beach_setting">
        <i class="fa fa-cog"></i>
    </a>
    <a id="reduce-screen" href="#" onclick="toggleFullScreen();">
        <i class="fa fa-compress"></i>
    </a>
</div>
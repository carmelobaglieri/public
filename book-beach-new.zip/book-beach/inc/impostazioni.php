<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/impostazioni.css' );?>">
<?php
	$righe = esc_attr( get_option('bb_righe') );
	$colonne = esc_attr( get_option('bb_colonne') );
	$feed = get_option('bb_feed');
?>

<div class="wrap">
	<h2>Impostazioni</h2>
	<p class="description">Queste sono le impostazioni <b>generali e necessarie</b> del gestionale. Inserisci <b>Righe</b> e <b>Colonne</b> per abilitare tutte le funzionalità.</p>
	<?php 
	?>
	<form method="post" action="options.php"> 
		<?php
		settings_fields( 'book_beach_settings' );
		do_settings_sections( 'book_beach_settings' );
		?>
		<table class="form-table">
	        <tr valign="top">
	        	<th scope="row">Righe</th>
	        	<td><input min="0" type="number" name="bb_righe" value="<?php echo $righe; ?>" /></td>
	        </tr>
	        <tr valign="top">
		        <th scope="row">Colonne</th>
		        <td><input min="0" type="number" name="bb_colonne" value="<?php echo $colonne; ?>" /></td>
	        </tr>
	        <?php 
	        if($feed){
	    		?>
	    		<tr valign="top">
			        <th scope="row">Link</th>
			        <td>
			        	<a style="line-height: 2;" href="<?php menu_page_url('book_beach'); ?>">Gestisci prenotazioni</a><br>
				        <a style="line-height: 2;" href="<?php menu_page_url('book_beach_price_setting'); ?>">Gestisci prezzi</a><br>
				        <a style="line-height: 2;" href="<?php menu_page_url('book_beach_clienti'); ?>">Gestisci Clienti</a>
				    </td>
		        </tr>
	    		<?php
	    	}
	    	?>
	        <input type="hidden" name="bb_feed" id="feed" value="" />
	    </table>

	    <div id="bb-setting-postazione">
		    <?php
		    if($righe && $colonne){
				?><hr><h3>Disabilita/Abilita postazione</h3>
				<p>Clicca sull'elemento per disabilitarlo definitivamente</p><?php
		    	echo '<table class="spiaggia">';
		    	for ($i=1; $i < $righe+1; $i++) { 
		    		echo '<tr>';
		    		for ($j=1; $j < $colonne+1; $j++) { 
			    		echo '<td data-id="'.$i.'-'.$j.'" data-status="'.checkBbPlaceStatus($feed,$i.'-'.$j).'"><label>'.$i.'-'.$j.'</label><div class="place"></div></td>';
			    	}
			    	echo '</tr>';
		    	}
		    	echo '</table>';
		    }
		    ?>
		</div>
	    <hr>
	    <?php submit_button(); ?>
	</form>

	</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
	function generaFeed(){
		var list = new Object();
		jQuery.each(jQuery('.spiaggia .place'),function(i,val){
			var el = new Object();
			el.id = jQuery(this).closest('td').attr('data-id');
			el.status = jQuery(this).closest('td').attr('data-status');
			list[i] = el;

		})
		jQuery('#feed').val(JSON.stringify(list));
	}
	generaFeed();
	jQuery('.spiaggia .place').on('click',function(){
		var status = jQuery(this).closest('td').attr('data-status');
		if(jQuery(this).closest('td').attr('data-status') == 'active'){
			jQuery(this).closest('td').attr('data-status','disabled');
		}else{
			jQuery(this).closest('td').attr('data-status','active');
		}
		generaFeed();
	})
})
</script>

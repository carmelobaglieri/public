<?php

global $book_beach_db_version;
$book_beach_db_version = '1.2';

function book_beach_table_install () {
	global $wpdb;
	global $book_beach_db_version;
	
	if ( !get_site_option( 'book_beach_db_version' ) ) {
		add_option( "book_beach_db_version", $book_beach_db_version );
	}

	$charset_collate = $wpdb->get_charset_collate();
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb"; 
	$prezzi_bb = $wpdb->prefix . "prezzi_bb"; 
	$clienti_bb = $wpdb->prefix . "clienti_bb"; 
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	$sql = "CREATE TABLE IF NOT EXISTS $prenotazioni_bb (
		id_prenotazione bigint(20) NOT NULL AUTO_INCREMENT,
		giorno date NOT NULL,
		postazione tinytext NOT NULL,
		id_cliente bigint(20) NOT NULL,
		note longtext,
		pagamento tinytext,
		importo tinytext,
		servizi mediumtext,
		giornata tinytext,
		PRIMARY KEY  (id_prenotazione)
		) $charset_collate; ";

	$sql .= "CREATE TABLE IF NOT EXISTS $prezzi_bb (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		giorno date NOT NULL,
		lettino mediumtext NOT NULL,
		prezzo mediumtext,
		PRIMARY KEY  (id)
		) $charset_collate; ";

	$sql .= "CREATE TABLE IF NOT EXISTS $clienti_bb (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		cognome tinytext NOT NULL,
		nome tinytext,
		telefono tinytext,
		PRIMARY KEY  (id)
		) $charset_collate; ";
	dbDelta( $sql );


	$wpdb->query("ALTER TABLE {$prenotazioni_bb} ADD presenza boolean;");

}

register_activation_hook( __FILE__, 'book_beach_table_install' );

function book_beach_update_db_check() {
    global $book_beach_db_version;
    if ( get_site_option( 'book_beach_db_version' ) != $book_beach_db_version ) {
        book_beach_table_install();
        update_site_option('book_beach_db_version',$book_beach_db_version);
    }
}
add_action( 'plugins_loaded', 'book_beach_update_db_check' );
<?php

include '../../../../wp-load.php';
global $wpdb;
$clienti_bb = $wpdb->prefix . "clienti_bb";
$prezzi_bb = $wpdb->prefix . "prezzi_bb"; 
$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb"; 

$righe = esc_attr( get_option('bb_righe') );
$colonne = esc_attr( get_option('bb_colonne') );
$feed = get_option('bb_feed');

if($_POST['action'] == 'update_bb_calendar'){
	/*single day booking results*/
	if($_POST['data']){
		$data = date('Y-m-d',strtotime($_POST['data']));
		echo update_singleday_booking_results($data);

	}
}
if($_POST['action'] == 'bb_aggiorna_tabella_prezzi'){
	/*single day booking results*/
	if($_POST['data']){
		$_data = explode('/', $_POST['data']);
		$data = $_data[2].'-'.$_data[1].'-'.$_data[0];

		$html .= '<table class="spiaggia loading">';
		for ($i=1; $i < $righe+1; $i++) { 
			$html .= '<tr>';
			for ($j=1; $j < $colonne+1; $j++) { 

				$active = checkBbPlaceStatus($feed,$i.'-'.$j);

				if($active == 'active'){

					$prezzo = ($_POST['section'] == 'singleday') ? getPrezzoByDataeLettino($data,$i.'-'.$j) : '';
					$prezzo = ($prezzo) ? number_format($prezzo,2,',','.').'€' : '';
					$fuel = ($prezzo) ? ' fuel ' : '';

		    		$html .= '<td data-id="'.$i.'-'.$j.'"><div class="place"><label>'.$i.'-'.$j.'</label><span class="price'.$fuel.'">'.$prezzo.'</span></div></td>';
				}else{
					$html .= '<td data-id="'.$i.'-'.$j.'"></td>';
				}
	    	}
	    	$html .= '</tr>';
		}
		$html .= '</table>';
		echo $html;
	}
}

if($_POST['action'] == 'bb_aggiorna_tabella_prenotazioni'){
	/*single day booking results*/
	if($_POST['data']){
		$_data = explode('/', $_POST['data']);
		$data = $_data[2].'-'.$_data[1].'-'.$_data[0];


		$html .= '<table class="spiaggia loading">';
		for ($i=1; $i < $righe+1; $i++) { 
			$html .= '<tr>';
			for ($j=1; $j < $colonne+1; $j++) { 

				$active = checkBbPlaceStatus($feed,$i.'-'.$j);

				if($active == 'active'){

					$_info = getInfoByData($data,$i.'-'.$j);

					//$prezzo = ($_POST['section'] == 'singleday') ? getPrezzoByDataeLettino($data,$i.'-'.$j) : '';
					//$prezzo = ($prezzo) ? number_format($prezzo,2,',','.').'€' : '';
					//$fuel = ($prezzo) ? ' fuel ' : '';
					if($_info){
						$cliente = getClienteByID($_info->id_cliente);
						$info = '<i class="fa fa-user"></i> '. $cliente->cognome . ' ' . $cliente->nome[0] . '.';
						$info .= '<br><i class="fa fa-credit-card"></i> ' . $_info->pagamento;
						if(checkAbbonamento($_info->id_cliente,$data)){
							$info .= '<br><i class="fa fa-address-card-o"></i> Abbonamento';
						}
						if($_info->giornata){
							$info .= '<br><i class="fa fa-ban"></i> Mezza g.';
						}

						$free = ' full ';
					}else{
						$info = '<span class="disponibile">Disponibile</span>';
						$free = ' free ';
					}
					ob_start();
					echo '<xmp>';
					print_r($_info);
					echo '</xmp>';
					$as = ob_get_contents();
					ob_end_clean();

					$presenza = '<div class="presenza"><input type="checkbox" '. ( $_info->presenza == 1 ? "checked" : "" ) . '/></div>';

		    		$html .= 	'<td data-prenotazione="'.$_info->id_prenotazione.'" class="'.strtolower($_info->pagamento).'" data-id="'.$i.'-'.$j.'">
						    		<div class="place '.$free.'">
							    		<label>'.$i.'-'.$j.'</label>'
							    		. $info .
						    		'</div>'
					    			. ($free == " full " ? $presenza : '') . 
					    		'</td>';
				}else{
					$html .= '<td data-id="'.$i.'-'.$j.'"></td>';
				}
	    	}
	    	$html .= '</tr>';
		}
		$html .= '</table>';
		echo $html;
	}
}

if($_POST['action'] == 'update_bb_prices'){
	$data = $_POST['data'];
	//$data = '[{"id":"1-4","data":"2019-02-02","prezzo":45},{"id":"1-4","data":"2019-02-03","prezzo":45},{"id":"1-4","data":"2019-02-04","prezzo":50.10}]';
	//echo $data;
	
	foreach ($data as $key) {
		$id = $key[id];
		//$data = $key[data];
		$data = $key[data];
		$prezzo = str_replace(',', '.', $key[prezzo]);

		$results = $wpdb->get_results("SELECT id FROM $prezzi_bb WHERE giorno = '$data' AND lettino='$id'");
		if(empty($results)){
			$wpdb->insert( 
				$prezzi_bb,
				array( 
					'giorno' => $data,
					'lettino' => $id,
					'prezzo' => $prezzo,
				),
				array( 
					'%s', 
					'%s', 
					'%s', 
				) 
			);
			$out = 'Prezzi inseriti!';
		}else{
			$wpdb->update( 
				$prezzi_bb,
				array( 
					'prezzo' => $prezzo,
				),
				array( 
					'id' => $results[0]->id,
					'giorno' => $data,
					'lettino' => $id,
				),
				array( 
					'%s', 
					'%s', 
					'%s', 
				) 
			);
			$out = 'Prezzi aggiornati!';
		}
	}
	echo $out;
}

if($_POST['action'] == 'add_prenotazione_periodo'){
/* 
Array
(
    [periodo] => 01-03-2019 - 03-03-2019
    [postazione] => 1-7,3-6,3-8
    [cognome] => Carmelo
    [nome] => Baglieri
    [note] => lkahsdbf" òasfhjg
    [pagamento] => Pagato
    [importo] => 245.5
    [giornata] => Mezza giornata
    [servizi] => Kit
    [telefono] => 3394087754
)
*/
	$data = json_decode(stripslashes($_POST['data']),true);

	$periodo = explode(' - ', $data['periodo']);
	$start = explode('-', $periodo[0]);
	$end = explode('-', $periodo[1]);
	$_end = new DateTime($end[2].'-'.$end[1].'-'.$end[0]);
	$_end = $_end->modify( '+1 day' );

	$periodo = new DatePeriod(
	     new DateTime($start[2].'-'.$start[1].'-'.$start[0]),
	     new DateInterval('P1D'),
	     $_end
	);


	/*controlla se il cliente esiste, altrimenti inserisci nuovo cliente*/
	if( getClienteByData($data['cognome'], $data['nome'], $data['telefono']) ){
		$id_cliente = getClienteByData($data['cognome'], $data['nome'], $data['telefono']);
	}else{
		$id_cliente = setCliente($data['cognome'], $data['nome'], $data['telefono']);
	}
	//print_r($periodo);
	$checkExist = false;
	$alert = "Impossibile aggiungere le seguenti prenotazioni:";
	foreach ($periodo as $key => $value) {
	    $giorno = $value->format('Y-m-d');
	    foreach (explode(',', $data['postazione']) as $pos) {
	    	if( getPrenotazione($giorno,$pos) ){
				$checkExist = true;
				$alert .= "\n" . $giorno . " pos: " . $pos;
	    	}else{
				$wpdb->insert( 
					$prenotazioni_bb, 
					array( 
						'giorno' => $giorno, 
						'postazione' => $pos ,
						'id_cliente' => $id_cliente ,
						'note' => $data['note'] ,
						'pagamento' => $data['pagamento'] ,
						'importo' => $data['importo'] ,
						'servizi' => $data['servizi'] ,
						'giornata' => $data['giornata'] ,
					)
				);
	    	}
	    }   
	}
	if ($checkExist == true) {
		echo json_encode($alert);
	}
	/*foreach ($periodo as $key => $value) {
	    $giorno = $value->format('Y-m-d');
	    foreach (explode(',', $data['postazione']) as $pos) {
	    }   
	}*/
}
if($_POST['action'] == 'add_prenotazione_giorno_singolo'){
/* 
Array
(
    [periodo] => 03/03/2019
    [postazione] => 3-6, 4-6
    [cognome] => Baglieri
    [nome] => Carmeloedit
    [note] => lkahsdbf" òasfhjg
    [pagamento] => Pagato
    [importo] => 245.50
    [giornata] => Mezza giornata
    [servizi] => Kit
    [telefono] => 3336051998
)
*/
	$data = json_decode(stripslashes($_POST['data']),true);

	$start = explode('/', $data['periodo'] );
	$_giorno = new DateTime($start[2].'-'.$start[1].'-'.$start[0]);


	/*controlla se il cliente esiste, altrimenti inserisci nuovo cliente*/
	if( getClienteByData($data['cognome'], $data['nome'], $data['telefono']) ){
		$id_cliente = getClienteByData($data['cognome'], $data['nome'], $data['telefono']);
	}else{
		$id_cliente = setCliente($data['cognome'], $data['nome'], $data['telefono']);
	}
	$postazione = explode(', ', $_POST['periodo']);
	//print_r($periodo);
    $giorno = $_giorno->format('Y-m-d');
    foreach (explode(', ', $data['postazione']) as $pos) {
    	$_preno = getPrenotazione($giorno,$pos);
    	if($_preno){
    		$wpdb->update( 
				$prenotazioni_bb, 
				array( 
					'giorno' => $giorno, 
					'postazione' => $pos ,
					'id_cliente' => $id_cliente ,
					'note' => $data['note'] ,
					'pagamento' => $data['pagamento'] ,
					'importo' => $data['importo'] ,
					'servizi' => $data['servizi'] ,
					'giornata' => $data['giornata'] ,
				),
				array( 'id_prenotazione' => $_preno->id_prenotazione )
			);
    	}else{
			$wpdb->insert( 
				$prenotazioni_bb, 
				array( 
					'giorno' => $giorno, 
					'postazione' => $pos ,
					'id_cliente' => $id_cliente ,
					'note' => $data['note'] ,
					'pagamento' => $data['pagamento'] ,
					'importo' => $data['importo'] ,
					'servizi' => $data['servizi'] ,
					'giornata' => $data['giornata'] ,
				)
			);
    	}
    }  
}

if($_POST['action'] == 'get_clienti'){
	$param = $_POST['param'];
	$chiave = $_POST['chiave'];

	$results = $wpdb->get_results("SELECT * FROM $clienti_bb WHERE $param LIKE '%$chiave%'");
	$json['id'] = $param;
	$json['dati'] = $results;
	echo json_encode($json);
}

if($_POST['action'] == 'get_prenotazione'){
	echo json_encode( getPrenotazione($_POST['giorno'],$_POST['id_postazione']));
}

if($_POST['action'] == 'get_riepilogo_note'){
	echo json_encode( getNoteByIdCliente($_POST['id_cliente']) );
}

if($_POST['action'] == 'get_cliente_by_id'){
	echo json_encode( getClienteByID($_POST['id']));
}

if($_POST['action'] == 'get_prenotazion_by_id_cliente'){
	$id = $_POST['id'];
	$results = $wpdb->get_results("SELECT * FROM $prenotazioni_bb WHERE id_cliente = '$id' ORDER BY giorno DESC");
	echo (count($results)) ? json_encode( $results ) : '';
}

if($_POST['action'] == 'get_date_by_postazione'){
	$postazione = $_POST['postazione'];
	$results = $wpdb->get_results("SELECT giorno FROM $prenotazioni_bb WHERE postazione = '$postazione' ORDER BY giorno ASC");
	echo (count($results)) ? json_encode( $results ) : '';
}

if($_POST['action'] == 'cancella_prenotazione'){
	$wpdb->delete( $prenotazioni_bb, array( 'id_prenotazione' => $_POST['id'] ) );
}

if($_POST['action'] == 'get_json_clienti'){
	echo getClienti();
}
if($_POST['action'] == 'aggiorna_cliente'){
	echo aggiornaCliente($_POST['id'], $_POST['cognome'], $_POST['nome'], $_POST['telefono']);
}
if($_POST['action'] == 'aggiorna_postazione'){
	if( $wpdb->update( 
		$prenotazioni_bb, 
		array( 
			'presenza' => $_POST['val'],
		), 
		array( 'id_prenotazione' => $_POST['id'] )
	) === false){
		echo 'Fallito';
	}else{
		echo 'Aggiornato';
	}
}
if($_POST['action'] == 'elimina_cliente'){
	eliminaCliente($_POST['id']);
}
if($_POST['action'] == 'aggiorna_prenotazione'){
	if( $wpdb->update( 
		$prenotazioni_bb, 
		array( 
			'giorno' => $_POST['giorno'],
			'postazione' => $_POST['postazione'],
			'importo' => $_POST['importo'],
			'pagamento' => $_POST['pagamento'],
		), 
		array( 'id_prenotazione' => $_POST['id'] )
	) === false){
		echo 'Fallito';
	}else{
		echo 'Prenotazione aggiornata';
	}
}
if($_POST['action'] == 'get_occupato_in_periodo'){
	$range = $_POST['range'];
	
	for ($i=1; $i < $righe+1; $i++) {
		for ($j=1; $j < $colonne+1; $j++) { 
			$active = checkBbPlaceStatus($feed,$i.'-'.$j);
			if( $active == 'active'){
				if( !isOccupatoInPeriodo($range, $i.'-'.$j) ){
					$html .= '<div class="bb-c-item" data-status="disabled" data-value="'.$i.'-'.$j.'">';
		            $html .= '<span class="icon"></span> <span class="text">'.$i.'-'.$j.'</span>';
		            $html .= '</div>';
				}else{
					$html .= '<div class="bb-c-item occuped" data-status="disabled" data-value="'.$i.'-'.$j.'">';
		            $html .= '<span class="icon"></span> <span class="text">'.$i.'-'.$j.'</span>';
		            $html .= '</div>';
				}
			}else{
				$html .= '<div class="bb-c-item not-active" data-status="disabled" data-value="'.$i.'-'.$j.'">';
	            $html .= $i.'-'.$j.'</span>';
	            $html .= '</div>';
			}
		}
	}
	echo $html;
	/*$giorno = $_POST['giorno'];
	$postazione = $_POST['id_postazione'];
	global $wpdb;
	$prenotazioni_bb = $wpdb->prefix . "prenotazioni_bb"; 
	$results = $wpdb->get_results("SELECT * FROM $prenotazioni_bb WHERE giorno = '$giorno' AND postazione='$postazione'");*/
}

if($_POST['action'] == 'update_importo_suggerito'){
	$type = $_POST['type'];
	$data = $_POST['data'];
	$postazioni = $_POST['postazioni'];
	
	if( $type && $data && $postazioni ){

		switch ($type) {
			case 'single':
				$tmp = explode('/', $data);
				$new_date = $tmp[2] . '-' . $tmp[1] . '-' . $tmp[0];
				foreach ($postazioni as $key) {
					$query .= "'" . trim($key) . "',";
				}
				$query = substr($query, 0, strlen($query)-1);
				if($new_date)
					$query = "SELECT SUM(prezzo) as somma FROM $prezzi_bb WHERE giorno = '$new_date' AND lettino IN ($query)";
				//SELECT SUM(prezzo) FROM wp3o_prezzi_bb WHERE giorno = '2019-04-12' AND lettino IN ('2-8','3-8')
				break;
			
			case 'period':
				$periodo = explode(' - ', $data);
				$start = explode('-', $periodo[0]);
				$end = explode('-', $periodo[1]);
				$_end = new DateTime($end[2].'-'.$end[1].'-'.$end[0]);
				$_end = $_end->modify( '+1 day' );

				$periodo = new DatePeriod(
				     new DateTime($start[2].'-'.$start[1].'-'.$start[0]),
				     new DateInterval('P1D'),
				     $_end
				);
				//periodo
				$array_date = array();
				foreach ($periodo as $key => $value) {
					array_push($array_date, "'" . trim($value->format('Y-m-d')) . "'");
				}

				$count = count($array_date);
				if($count > 6){
					$gratis = round($count/7);
					for ($i=1; $i <= $gratis; $i++) { 
						unset($array_date[$i*6]);
					}
					$list_date = implode(',', $array_date);
				}
				
				//postazioni
				$postazioni = stripslashes($postazioni);
				$postazioni = str_replace('"', "'", $postazioni);
				$postazioni = str_replace('[', "", $postazioni);
				$postazioni = str_replace(']', "", $postazioni);
				/*
				SELECT SUM(prezzo) as somma FROM wp3o_prezzi_bb WHERE giorno IN ('2019-04-15','2019-04-16','2019-04-17') AND lettino IN ('1-4','3-6','9-9','10-5','10-6','10-7','10-8','10-9')
				*/
				$query = "SELECT SUM(prezzo) as somma FROM $prezzi_bb WHERE giorno IN ($list_date) AND lettino IN ($postazioni)";

				break;
		}
		$results = $wpdb->get_results($query);
		echo ($results[0]) ? number_format(floatval($results[0]->somma),2,',','.') : 0;

	}
}

?>
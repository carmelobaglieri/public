<?php
/*
Plugin Name: Book Beach
Plugin URI: https://www.wikiwebagency.it
Description: Prenotazione lettini da spiaggia
Version: 1.6
Author: Carmelo Baglieri
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

global $file_ver;
$file_ver = '2.0';

require_once 'inc/admin_menu.php';
require_once 'inc/functions.php';
require_once 'inc/db.php';
require_once 'inc/options.php';
require_once 'inc/shortcodes.php';

$feed = get_option('bb_feed');

if(!$feed && $_GET['page'] != 'book_beach_setting' && strpos($_SERVER['REQUEST_URI'],'book_beach')){
	header('Location: '.get_site_url().'/wp-admin/admin.php?page=book_beach_setting');
}

// attivazione

function activate_book_beach() {
   bbCreateRole();
}
// Register our activation hook
register_activation_hook( __FILE__, 'activate_book_beach' );

function deactivate_book_beach() {

  $role = get_role( 'author' );
  $role->remove_cap( 'manage_options' ); // capability
}
// Register our de-activation hook
register_deactivation_hook( __FILE__, 'deactivate_book_beach' );

// ================================================================================= Aggiungi link alle impostazioni nella pagina plugins

    function book_beach_add_settings_link( $links ) {
        $settings_link = '<a href="admin.php?page=book_beach_setting">' . __( 'Impostazioni' ) . '</a>';
        array_push( $links, $settings_link );
        return $links;
    }
    $plugin = plugin_basename( __FILE__ );
    add_filter( "plugin_action_links_$plugin", 'book_beach_add_settings_link' );

    add_action('wp_head', 'add_front_style_book_beach');
	function add_front_style_book_beach() {
		?>
		<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/moment.min.js' );?>"></script>
		<script type="text/javascript" src="<?php echo plugins_url( 'book-beach/js/daterangepicker.min.js' );?>"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/daterangepicker.css' );?>">
		<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/general.css' );?>">
		<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( 'book-beach/css/front.css' );?>">
		<?php
		wp_enqueue_script('scripts', plugins_url() . '/book-beach/js/scripts.js');
		wp_localize_script('scripts', 'bbScripts', array(
		    'pluginsUrl' => plugins_url(),
		));
	}

?>
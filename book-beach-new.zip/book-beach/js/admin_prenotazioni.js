var plugin_url = bbAdmin_prenotazioni.pluginUrl;
var clienti_url = bbAdmin_prenotazioni.clienti_url;
var startDate = moment().startOf('hour').format('YYYY-MM-DD');

jQuery(document).ready(function(){
	populatePeriod();
});

/*trigger place */
jQuery('.spiaggia').on('click','.place.free',function(){
	if(jQuery(this).hasClass('checked')){
		jQuery(this).removeClass('checked');
	}else{
		jQuery(this).addClass('checked');
	}
	if(hasLettini()){
		jQuery('#add-single-order').show();
	}else{
		jQuery('#add-single-order').hide();
	}
});


/*trigger continue SINGLE  */
jQuery('#add-single-order').on('click',function(){
	if(hasLettini()){
		jQuery('#postazione-selezionata').text(getLettiniSelezionati().toString().replace(/,/g, ", "));
		jQuery('#data-selezionata').text(jQuery('#singleday').val());
		jQuery('#modal-form').addClass('visible');
		jQuery('#modal-form').attr('data-status','single');
		updateImportoSuggerito('single');
	}
});

/*trigger nuova prenotazione PERIOD */
jQuery('#add-period-order').on('click',function(){
	jQuery('#modal-form').addClass('visible');
	jQuery('#modal-form').attr('data-status','period');
	jQuery('#importo-suggerito span').text('- €');
})
jQuery(document).on('click','#selezione-lettini .bb-c-item',function(){
	updateImportoSuggerito('period');
})

/*trigger click su postazione già prenotata*/
jQuery(document).on('click','.place.full',function(){
	jQuery('#riepilogo-note').text('Apri riepilogo');
	jQuery('#prenotazioni-cliente').text('Vai alle prenotazioni');
	var id_postazione = jQuery(this).parent().attr('data-id');
	var data = getPrenotazione(startDate,id_postazione);

	jQuery('#modal-form').addClass('visible');
	jQuery('#modal-form').attr('data-status','single');

	jQuery('#data-selezionata').text( jQuery('#singleday').val() );

	var cliente = getCliente(data.id_cliente);
	jQuery('#cognome').val( cliente.cognome );
	jQuery('#nome').val( cliente.nome );
	jQuery('#telefono').val( cliente.telefono );
	jQuery('#riepilogo-note').attr( 'data-id-cliente', data.id_cliente );
	jQuery('#prenotazioni-cliente').attr( 'href', clienti_url+'&id='+data.id_cliente );
	jQuery('#note').val( data.note );
	jQuery('#importo').val( data.importo );
	jQuery('#postazione-selezionata').text( data.postazione );
	if(data.servizi){
		jQuery.each(data.servizi.split(','),function(i, val){
			jQuery('#servizi').find('[data-value="'+val+'"]').attr('data-status','checked');
		})
	}
	if(data.giornata){
		jQuery.each(data.giornata.split(','),function(i, val){
			jQuery('#giornata').find('[data-value="'+val+'"]').attr('data-status','checked');
		})
	}
	jQuery('#typepay').find('[data-value="'+data.pagamento+'"]').trigger('click');

	jQuery('#add-prenotazione').before('<button class="bb-btn red" id="remove-prenotazione" data-id="'+data.id_prenotazione+'">Cancella prenotazione</button>');
	jQuery('#add-prenotazione').attr('data-id',data.id_prenotazione);
})
/*load riepilogo note on click*/
jQuery(document).on('click','#riepilogo-note',function(){
	var id_cliente = jQuery(this).attr('data-id-cliente');
	if( !jQuery(this).hasClass('setted') ){
		var note = getRiepilogoNote(id_cliente);
		var out = '';
		jQuery.each(note,function(i,val){
			out += "<b>Giorno:</b> " + inverseDate(val.giorno,'-','/');
			out += " <b>Pos.:</b> " + val.postazione;
			out += " <b>Nota:</b> " + val.note;
			out += " <b>Pag.:</b> " + val.pagamento + "<br>";
		})
		jQuery(this).parent().after("<p id='lista-note'>"+out+"</p>");
		jQuery(this).addClass('setted');
	}else{
		jQuery('#lista-note').slideToggle(500);
	}
});
/*cancella prenotazione*/
jQuery(document).on('click','#remove-prenotazione',function(){
	var id = jQuery(this).attr('data-id');
	if( confirm("Sei sicuro di voler cancellare la prenotazione?") ){
		jQuery.ajax({
			type: "POST",
			url: plugin_url+"/inc/parser.php",
			data: {
				id: id,
				action: 'cancella_prenotazione'
			},
			success  : function(msg){
				alert('Prenotazione cancellata!');
				clearForm(jQuery('#modal-form'));
				aggiornaTabella();
			} ,
			error    : function(msg) { alert("Fallito"); } 
		});
	}
})

/*modal*/


jQuery('#modal-form .close').click(function(){
	var modal = jQuery(this).closest('#modal-form');
	clearForm(modal);

})

/*salva prenotazione*/
function aggiungiPrenotazione(){
	/*controllo campi*/
	if( !jQuery('#cognome').val() ){
		alert('Inserire un cognome');
		return;
	}
	if( !jQuery('#nome').val() ){
		alert('Inserire un nome');
		return;
	}
	if( !jQuery('#telefono').val() ){
		alert('Inserire un numero di telefono');
		return;
	}
	if( !jQuery('#importo').val() ){
		alert('Inserire importo pagato altrimenti inserire 0');
		return;
	}

	/* ==========PRENOTAZIONE */

	var modalStatus = jQuery('#modal-form').attr('data-status');
	//definizione oggetto prenotazione
	var obj = {};
	//dati cliente
	obj.cognome = jQuery('#cognome').val();
	obj.nome = jQuery('#nome').val();
	obj.telefono = jQuery('#telefono').val();
	//note
	obj.note = jQuery('#note').val();
	//tipo pagamento
	obj.pagamento = jQuery('#typepay [data-status="active"]').attr('data-value');
	//importo
	obj.importo = jQuery('#importo').val();
	//giornata
	if(jQuery('#giornata .bb-c-item').first().attr('data-status') == 'checked'){
		obj.giornata = jQuery('#giornata .bb-c-item').first().attr('data-value');
	}
	//servizi
	var servizi = [];
	jQuery.each(jQuery('#servizi .bb-c-item'),function(i,val){
		if(jQuery(this).attr('data-status') == 'checked'){
			servizi.push(jQuery(this).attr('data-value'));
		}
	})
	obj.servizi = servizi.join();

	/* PER PERIODO*/
	if(modalStatus == 'period'){
		//periodo
		obj.periodo = jQuery('#multiday').val();
		//postazioni
		var lettini = [];
		jQuery.each(jQuery('#selezione-lettini .bb-c-item'),function(i,val){
			if(jQuery(this).attr('data-status') == 'checked'){
				lettini.push(jQuery(this).attr('data-value'));
			}
		})
		obj.postazione = lettini.join();

		var action = 'add_prenotazione_periodo';
	}
	/* PER GIORNO SINGOLO*/
	if(modalStatus == 'single'){
		//periodo
		var giorno = jQuery('#singleday').val().split(' ');
		obj.periodo = giorno[1];
		//postazioni
		obj.postazione = jQuery('#postazione-selezionata').text();

		var action = 'add_prenotazione_giorno_singolo';
	}

	var json = JSON.stringify(obj);
	//inserisci valori
	jQuery.ajax({
		type: "POST",
		url: plugin_url+"/inc/parser.php",
		data: {
			data: json,
			action: action
		},
		success  : function(msg){
			if(msg){
				alert(JSON.parse(msg));
			}else{
				alert('Prenotazione inserita!');
			}
			clearForm(jQuery('#modal-form'));
			aggiornaTabella();
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});

}

jQuery('#add-prenotazione').click(function(){
	if( confirm("Sei sicuro di voler inserire la prenotazione?") ){
		aggiungiPrenotazione();
	}
});

/*correggi valore importo*/
jQuery('#importo').on('change keyup keydown paste',function(){
	jQuery(this).val( jQuery(this).val().replace(',','.') );
});

/*ajax search cliente*/
jQuery('#cognome,#nome,#telefono').on('keypress',function(){
	if(jQuery(this).val().length > 3){
		jQuery.ajax({
			type: "POST",
			url: plugin_url+"/inc/parser.php",
			data: {
				param: jQuery(this).attr('id'),
				chiave: jQuery(this).val(),
				action: 'get_clienti'
			},
			success  : function(msg){
				var json = JSON.parse(msg);

				if(!jQuery('#'+json['id']).parent().find('.ajaxSearchCliente').length){
					jQuery('#'+json['id']).parent().css('position','relative');
					jQuery('#'+json['id']).after('<div class="ajaxSearchCliente"></div>');
				}
				jQuery('.ajaxSearchCliente').empty();
				for (var i = 0; i < json['dati'].length; i++) {
					var el = json['dati'][i];
					jQuery('#'+json['id']).parent().find('.ajaxSearchCliente').append('<span class="item-result"><span class="cognome">'+el['cognome']+'</span> <span class="nome">'+el['nome']+'</span> <span class="telefono">'+el['telefono']+'</span></span>');
				};

				/*var dati = msg.split(':::');
				var id = dati[0];
				var options = dati[1];
				*/
			} ,
			error    : function(msg) { alert("Fallito"); } 
		});
	}
});

jQuery(document).on('click','.ajaxSearchCliente .item-result',function(){
	jQuery('#cognome').val( jQuery(this).find('.cognome').text() );
	jQuery('#nome').val( jQuery(this).find('.nome').text() );
	jQuery('#telefono').val( jQuery(this).find('.telefono').text() );
	jQuery('.ajaxSearchCliente').empty();
})

function getDateByPostazione(pos){
	var html = '';
	jQuery.ajax({
		type: "POST",
		dataType: 'json',
		url: plugin_url+"/inc/parser.php",
		data: {
			postazione: pos,
			action: 'get_date_by_postazione'
		},
		async: false,
		success  : function(msg){
			html = msg;
		} ,
		error    : function(msg) { alert("Fallito"); } 
	});
	return html;
}

function addCCla(date){
	var periodi = [];
	for (var i = 0; i < date.length; i++) {
		periodi[i] = date[i].giorno;
	};

	jQuery( "#calendar-date-occupate" ).datepicker({ 
		minDate: new Date(startDate), 
		maxDate: new Date(endDate),
		onSelect: function(date, el) {
		    jQuery(this).data('datepicker').inline = true;

			var day  = el.selectedDay,
                mon  = el.selectedMonth,
                year = el.selectedYear;
			var el = jQuery(el.dpDiv).find('[data-year="'+year+'"][data-month="'+mon+'"]').filter(function() {
                    return jQuery(this).find('a').text().trim() == day;
                });
			if( el.hasClass('occuped') ){
			    var newdate = inverseDate(date,'/','-')
			    var link = window.location.protocol+'//'+window.location.hostname+window.location.pathname;
			    window.open(link+'?page=book_beach&date='+newdate);
			}
		},
		onClose: function() {
			jQuery(this).datepicker('destroy');
		},
		beforeShowDay: function(date){
			var curr = date.getFullYear() + '-' + ("0" + (date.getMonth() + 1)).slice(-2) + '-' + ("0" + date.getDate()).slice(-2);
			var start = new Date(startDate).setHours(0,0,0);
			var end = new Date(endDate).setHours(0,0,0);
			if(start <= date && date <= end){
				var present = jQuery.inArray(curr, periodi) > -1;
				if(present){
					//vero
					return [true, 'inrange occuped'];
				}else{
					//falso
					return [true, 'inrange'];
				}
			}else{
				return [false, 'outrange'];
			}
		}
	});
	jQuery( "#calendar-date-occupate" ).datepicker('show')
}
jQuery(document).on('click','#selezione-lettini .bb-c-item.occuped .text', function(){
	var date = getDateByPostazione(jQuery(this).parent().attr('data-value'));
	if(date)
		addCCla(date);
})
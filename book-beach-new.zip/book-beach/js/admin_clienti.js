var plugin_url = bbAdmin_clienti.pluginUrl;

jQuery(document).on("keyup keydown", function(e){
   if ((e.ctrlKey || e.metaKey) && e.keyCode === 70) {
    e.preventDefault();
    jQuery("#tabella-clienti_filter input").focus();
   }
});      

/*SWITCH FULL SCREEN*/
function toggleFullScreen() {
	/*if (document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement) {
	    if (document.cancelFullScreen) {
	        document.cancelFullScreen();
	    } else {
	        if (document.mozCancelFullScreen) {
	            document.mozCancelFullScreen();
	        } else {
	            if (document.webkitCancelFullScreen) {
	                document.webkitCancelFullScreen();
	            }
	        }
	    }
	    jQuery('.wrap-bb').removeClass('full-screen');
	} else {
	    const _element = document.documentElement;
	    if (_element.requestFullscreen) {
	        _element.requestFullscreen();
	    } else {
	        if (_element.mozRequestFullScreen) {
	            _element.mozRequestFullScreen();
	        } else {
	            if (_element.webkitRequestFullscreen) {
	                _element.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
	            }
	        }
	    }
	    jQuery('.wrap-bb').addClass('full-screen');
	}*/
	jQuery('.wrap-bb').toggleClass('full-screen');
}
function getJsonClienti(){
	var json = null;
	jQuery.ajax({
		url: plugin_url+"/inc/parser.php",
		type: "POST",
		dataType: "json",
		async: false,
		data: {
			action: 'get_json_clienti'
		},
		success  : function(msg){
			json = msg;
		} ,
		error    : function(msg) { console.log("Failed"); } 
	});
	return json;
}
//modifica
jQuery(document).on('click','#tabella-clienti .edit',function(e){
	var id = jQuery(this).attr('data-id');
	e.preventDefault();
	if(jQuery('#'+id+' .cognome input').length > 0){
		return;
	}

	var cognome = jQuery('#'+id+' .cognome').text();
	jQuery('#'+id+' .cognome').html('<input type="text" value="'+cognome+'">');

	var nome = jQuery('#'+id+' .nome').text();
	jQuery('#'+id+' .nome').html('<input type="text" value="'+nome+'">');

	var telefono = jQuery('#'+id+' .telefono').text();
	jQuery('#'+id+' .telefono').html('<input type="text" value="'+telefono+'">');
	
})
//salva
jQuery(document).on('click','#tabella-clienti .salva',function(e){
	var id = jQuery(this).attr('data-id');

	var cognome = (typeof jQuery('#'+id+' .cognome input').val() !== 'undefined')?jQuery('#'+id+' .cognome input').val():jQuery('#'+id+' .cognome')[0].innerHTML;
	var nome = (typeof jQuery('#'+id+' .nome input').val() !== 'undefined')?jQuery('#'+id+' .nome input').val():jQuery('#'+id+' .nome')[0].innerHTML;
	var telefono = (typeof jQuery('#'+id+' .telefono input').val() !== 'undefined')?jQuery('#'+id+' .telefono input').val():jQuery('#'+id+' .telefono')[0].innerHTML;

	jQuery.ajax({
		url: plugin_url+"/inc/parser.php",
		type: "POST",
		dataType: "json",
		async: false,
		data: {
			action: 'aggiorna_cliente',
			id: id,
			cognome: cognome,
			nome: nome,
			telefono: telefono,
		},
		success  : function(msg){
			alert('Contatto aggiornato')
		} ,
		error    : function(msg) { console.log("Failed"); } 
	});
	jQuery('#'+id+' .cognome').html(cognome);
	jQuery('#'+id+' .nome').html(nome);
	jQuery('#'+id+' .telefono').html(telefono);

	jQuery('#'+id+' td').addClass('updated');

	setTimeout(function(){
		jQuery('#'+id+' td').removeClass('updated');
	},700)

})

//elimina
jQuery(document).on('click','#tabella-clienti .elimina',function(e){
	var id = jQuery(this).attr('data-id');

	var cognome = jQuery('#'+id+' .cognome').text();
	var nome = jQuery('#'+id+' .nome').text();

	if( confirm('Eliminare '+cognome+' '+nome+'?') ){
		jQuery.ajax({
			url: plugin_url+"/inc/parser.php",
			type: "POST",
			dataType: "json",
			async: false,
			data: {
				action: 'elimina_cliente',
				id: id
			},
			success  : function(msg){
				jQuery('#'+id).remove();
				alert('Contatto eliminato');
			} ,
			error    : function(msg) { console.log("Failed"); } 
		});
	}

});

/*vedi prenotazioni*/
jQuery(document).on('click','button[data-modal-id]',function(e){
	var id = jQuery(this).attr('data-modal-id');
	var inner = jQuery('#'+id+' .inner');
	jQuery(inner).append('Caricamento...');
	var id_cliente = jQuery(this).attr('data-id');
	var cognome = jQuery('tr[id='+id_cliente+']').find('.cognome').text();
	var nome = jQuery('tr[id='+id_cliente+']').find('.nome').text();

	var data = getPrenotazioniCliente(id_cliente);
	var out = '<h2>'+cognome+' '+nome+'</h2>';
	out += '<table data-id-cliente="'+id_cliente+'" class="prenotazioniCliente">';
	out += '<thead>';
		out += '<th>Giorno</th>';
		out += '<th>Postazione</th>';
		out += '<th>Importo &euro;</th>';
		out += '<th>Pagamento</th>';
		out += '<th class="operazioni"></th>';
	out += '</thead>';
	out += '<tbody>';
	jQuery.each(data,function(i,val){
		var elimina = "<button data-id=\""+val.id_prenotazione+"\" class=\"elimina\"><i class=\"fa fa-trash\"></i></button>";
		var salva = "<button data-id=\""+val.id_prenotazione+"\" class=\"edit\"><i class=\"fa fa-pencil\"></i></button>";


		out += '<tr>';
			out += '<td class="giorno" data-giorno="'+val.giorno+'">'+inverseDate(val.giorno)+'</td>';
			out += '<td class="postazione">'+val.postazione+'</td>';
			out += '<td class="importo">'+val.importo+'</td>';
			var segna_pagato = (val.pagamento == 'Acconto') ? '<span class="segna-pagato as-link">-> Pagato</span>' : '';
			out += '<td class="pagamento">'+val.pagamento+segna_pagato+'</td>';
			out += '<td class="operazioni">'+elimina+salva+'</td>';
		out += '</tr>';
	});
	out += '</tbody>';
	out += '</table>';

	jQuery(inner).html( out );

});

jQuery(document).on('click','.prenotazioniCliente .elimina',function(){
	cancellaPrenotazione( jQuery(this).attr('data-id'));
	if( gbl_response == true ){
		var riga = jQuery(this).closest('tr');
		riga.fadeOut(1000,function(){
			this.remove();
		});
	}
})
jQuery(document).on('click','.prenotazioniCliente .edit',function(){
	var riga = jQuery(this).closest('tr');
	riga.find('.giorno').html('<input type="text" value="'+riga.find('.giorno').text()+'">');
	riga.find('.postazione').html('<input type="text" value="'+riga.find('.postazione').text()+'">');
	riga.find('.importo').html('<input type="text" value="'+riga.find('.importo').text()+'">');
	riga.find('.segna-pagato').remove();
	riga.find('.pagamento').html('<input type="text" value="'+riga.find('.pagamento').text()+'">');
	riga.find('.edit').removeClass('edit').addClass('salva');
	riga.find('.salva i').removeClass('fa-pencil').addClass('fa-save');
})

jQuery(document).on('click','.prenotazioniCliente .salva',function(){
	var riga = jQuery(this).closest('tr');
	var id = jQuery(this).attr('data-id');
	var giorno = riga.find('.giorno input').val();
	var postazione = riga.find('.postazione input').val();
	var importo = riga.find('.importo input').val();
	var pagamento = riga.find('.pagamento input').val();
	//console.log(id,giorno,postazione,importo,pagamento)
	aggiornaPrenotazione(id,inverseDate(giorno,'-','-'),postazione,importo,pagamento);
	riga.find('.giorno').html(giorno);
	riga.find('.postazione').html(postazione);
	riga.find('.importo').html(importo);
	if(pagamento.toLowerCase() != 'pagato'){
		pagamento += '<span class="segna-pagato as-link">-> Pagato</span>';
	}
	riga.find('.pagamento').html(pagamento);
	riga.find('.salva').removeClass('salva').addClass('edit');
	riga.find('.edit i').removeClass('fa-save').addClass('fa-pencil');
})

jQuery(document).on('click','.segna-pagato',function(){
	var riga = jQuery(this).closest('tr');
	var giorno = riga.find('.giorno').attr('data-giorno');
	var postazione = riga.find('.postazione').text();
	var data = getPrenotazione(giorno,postazione);
	aggiornaPrenotazione(data.id_prenotazione,giorno,postazione,data.importo,'Pagato');
	riga.find('.pagamento').text('Pagato');
});
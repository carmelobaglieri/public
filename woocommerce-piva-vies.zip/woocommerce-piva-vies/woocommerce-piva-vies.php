<?php
/*
Plugin Name: Partiva Iva con controllo Vies per Woocommerce
Plugin URI: http://www.wikiwebagency.it
Description: Aggiunge campi Partita IVA e Codice Fiscale al checkout e permette il controllo dei valori in base al registro VIES e alle regex.
Version: 3.2
Author: Carmelo Baglieri
Text Domain: woocommerce_vies
Domain Path: /languages/
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

    global $woo_piva_vies_vers;
    $woo_piva_vies_vers = '3.2.4';

    // ================================================================================= Registra lingua

    add_action( 'init', function(){
        load_plugin_textdomain( 'woocommerce_vies', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    });

    // ================================================================================= Aggiungi link alle impostazioni nella pagina plugins

    function piva_vies_add_settings_link( $links ) {
        $settings_link = '<a href="admin.php?page=wc-settings&tab=tax">' . __( 'Settings', 'woocommerce_vies' ) . '</a>';
        array_push( $links, $settings_link );
        return $links;
    }
    $plugin = plugin_basename( __FILE__ );
    add_filter( "plugin_action_links_$plugin", 'piva_vies_add_settings_link' );

    // ================================================================================= Carica il foglio di stile

    function loading_file()
    {
    	global $woo_piva_vies_vers;
    	wp_register_style('piva-vies-style', WP_PLUGIN_URL . '/woocommerce-piva-vies/css/style.css', null, $woo_piva_vies_vers, 'all');
        wp_enqueue_style('piva-vies-style');
    }
    add_action('wp_enqueue_scripts','loading_file');

    // ================================================================================= Carica scripts
    function loading_scripts() {
    	global $woo_piva_vies_vers;
        $verde = (get_option('piva_vies_section_verde')) ? get_option('piva_vies_section_verde') : 'green' ;
        $rosso = (get_option('piva_vies_section_rosso')) ? get_option('piva_vies_section_rosso') : 'red' ;
        $codiceNazione = get_option('piva_vies_section_codice_nazione');
        $pIva = get_option('piva_vies_section_piva');

        wp_register_script( 'script', WP_PLUGIN_URL . '/woocommerce-piva-vies/js/script.js',  array( 'jquery' ), $woo_piva_vies_vers, true );
        $active = ( get_option('check_vies_plugin') == 'yes' ) ? 'yes' : 'no';

        $vars = array(
            'plugin_url' => WP_PLUGIN_URL,
            'check_active' => $active,
            'verde' => $verde,
            'rosso' => $rosso,
            'codiceNazione' => $codiceNazione,
            'pIva' => $pIva,
        );
        wp_localize_script( 'script', 'obj_var', $vars );
        wp_enqueue_script( 'script' );
    }

    add_action( 'wp_enqueue_scripts', 'loading_scripts' );

    // =================================================================================  AGGIUNGI I CAMPI IN CASSA

    add_filter('woocommerce_billing_fields', 'custom_woocommerce_billing_fields');

    function custom_woocommerce_billing_fields($fields)
    {
        $update = array();
        $first = true;
        foreach ($fields as $key => $value) {
            if($first == true){
                $update['billing_invoice_type'] = array(
                    'label' => __('Private or Company?','woocommerce_vies'),
                    'placeholder' => __("Select an option",'woocommerce_vies'),
                    'required'    => true,
                    'clear'       => false,
                    'type'        => 'select',
                    'options'     => array(
                        'not_selected' => __("Select an option",'woocommerce_vies'),
                        'privato' => __('Private','woocommerce_vies'),
                        'azienda' => __('Company','woocommerce_vies'),
                    ),
                    'value'       => get_user_meta( get_current_user_id(), 'billing_invoice_type', true )
                );
                $first = false;
            }
            $update[$key] = $value;
            if($key == 'billing_company'){
                $update[$key] = $value;
                $update['billing_partita_iva'] = array(
                    'label' => __('VAT number','woocommerce_vies'), // Add custom field label
                    //'placeholder' => __('Inserisci la partita IVA','woocommerce_vies'), // Add custom field placeholder
                    'required' => false, // if field is required or not
                    'clear' => false, // add clear or not
                    'type' => 'text', // add field type
                    'class' => array('form-row-wide validate-required')    // add class name
                );
                $update['billing_cod_fisc'] = array(
                    'label' => __('Fiscal Code','woocommerce_vies'), // Add custom field label
                    //'placeholder' => __('Inserisci il codice fiscale','woocommerce_vies'), // Add custom field placeholder
                    'required' => true, // if field is required or not
                    'clear' => false, // add clear or not
                    'type' => 'text', // add field type
                    'class' => array('form-row-wide validate-required')    // add class name
                );
                $update['billing_method_type'] = array(
                    'label' => __('Choose Electronic Billing Method','woocommerce_vies'),
                    'placeholder' => __("Select an option",'woocommerce_vies'),
                    'required'    => true,
                    'clear'       => false,
                    'type'        => 'select',
                    'options'     => array(
                        'not_selected' => __("Select an option",'woocommerce_vies'),
                        'pec' => __('PEC','woocommerce_vies'),
                        'codice_destinatario' => __('Recipient Code','woocommerce_vies'),
                        'altro' => __('Other','woocommerce_vies'),
                    ),
                    'value'       => get_user_meta( get_current_user_id(), 'billing_method_type', true )
                );
                $update['billing_pec_email'] = array(
                    'label'       => __('PEC', 'woocommerce_vies'),
                    'placeholder' => __('For Electronic Bill', 'woocommerce_vies'),
                    'required'    => false,
                    'type'        => 'text',
                    'class' => array('form-row-wide validate-required'),
                    'clear'       => true,

                );
                $update['billing_codice_destinatario'] = array(
                'label'       => __('Recipient Code', 'woocommerce_vies'),
                'placeholder' => __('For Electronic Bill', 'woocommerce_vies'),
                'required'    => false,
                'type'        => 'text',
                'class' => array('form-row-wide validate-required'),
                'clear'       => true,

                );
            }

        }



        if(isset($_POST['billing_invoice_type'])){
            switch($_POST['billing_invoice_type']){
                case "azienda":
                    $update['billing_cod_fisc']['required'] = true;
                    $update['billing_partita_iva']['required'] = true;

                    $update['billing_pec_email']['required'] = ($_POST['billing_method_type'] == 'pec') ? true : false;
                    $update['billing_codice_destinatario']['required'] = ($_POST['billing_method_type'] == 'codice_destinatario' )? true : false;

                    $update['billing_company']['required'] = true;
                    break;
                case "privato":
                    $update['billing_cod_fisc']['required'] = true;
                    $update['billing_partita_iva']['required'] = false;
                    
                    $update['billing_pec_email']['required'] = ($_POST['billing_method_type'] == 'pec') ? true : false;
                    $update['billing_codice_destinatario']['required'] = ($_POST['billing_method_type'] == 'codice_destinatario' )? true : false;

                    $update['billing_company']['required'] = false;
                    break;
                default:
                    $update['billing_cod_fisc']['required'] = true;
                    $update['billing_partita_iva']['required'] = false;
                    $update['billing_pec_email']['required'] = false;
                    $update['billing_codice_destinatario']['required'] = false;
                    $update['billing_company']['required'] = false;
                    break;
            }

        }
        return $update;
    }

    //
    add_action('woocommerce_checkout_process', 'notice_fields');

    function notice_fields() {
                
        if ( $_POST['billing_invoice_type'] == 'not_selected' )
            wc_add_notice( __( 'Choose if you are Private or Company', 'woocommerce_vies' ), 'error' );
        if ( $_POST['billing_method_type'] == 'not_selected' )
            wc_add_notice( __( 'Choose your billing method', 'woocommerce_vies' ), 'error' );

    }

    // =================================================================================  AGGIUNGI IL CAMPO PARTITA IVA NEL RIEPILOGO ORDINE (ADMIN)
    
    add_filter('woocommerce_admin_billing_fields', 'custom_admin_billing_fields');

    function custom_admin_billing_fields($fields){
        $fields['partita_iva'] = array(
        'label' => 'Partita IVA',
        'show' => true,
        );
        $fields['cod_fisc'] = array(
        'label' => 'Codice Fiscale',
        'show' => true,
        );
        $fields['pec_email'] = array(
        'label' => 'PEC',
        'show' => true,
        );
        $fields['codice_destinatario'] = array(
        'label' => 'Codice Destinatario',
        'show' => true,
        );
        return $fields;
    }

    // =================================================================================  AGGIUNGI IL CAMPO PARTITA IVA NEL PROFILO USER (ADMIN)

    add_filter('woocommerce_customer_meta_fields', 'custom_customer_meta_fields');

    function custom_customer_meta_fields($fields){
        $fields['billing']['fields']['billing_partita_iva'] = array(
            'label'       => 'Partita IVA',
        );
        $fields['billing']['fields']['billing_cod_fisc'] = array(
            'label'       => 'Codice Fiscale'
        );
        $fields['billing']['fields']['billing_pec_email'] = array(
            'label'       => 'PEC'
        );
        $fields['billing']['fields']['billing_codice_destinatario'] = array(
            'label'       => 'Codice Destinatario'
        );
        return $fields;
    }

    // =================================================================================  AGGIUNGI I CAMPI NELL'EMAIL
    /*add_filter( 'woocommerce_email_order_meta_fields', 'custom_woocommerce_email_order_meta_fields', 10, 3 );

    function custom_woocommerce_email_order_meta_fields( $fields, $sent_to_admin, $order ) {
        $fields['_billing_partita_iva'] = array(
            'label' => traduci( 'Partita IVA' ),
            'value' => get_post_meta( $order->id, '_billing_partita_iva', true ),
        );
        $fields['_billing_cod_fisc'] = array(
            'label' => traduci( 'Codice Fiscale' ),
            'value' => get_post_meta( $order->id, '_billing_cod_fisc', true ),
        );
        return $fields;
    }*/

    // =================================================================================  AGGIUNGI TAB ALIQUOTA SU PAGINA PRODOTTO

    /*function custom_product_data_tabs($tabs){
        $tabs['aliquota_piva_vies'] = array(
            'label' => __('VIES tax rates', 'woocommerce'),
            'target' => 'aliquota_piva_vies_options',
            'class' => array('show_if_simple','show_if_variable')
        );

        return $tabs;
    }

    add_filter('woocommerce_product_data_tabs', 'custom_product_data_tabs' );

    function my_custom_product_tab_content(){
        ?> <div id="aliquota_piva_vies_options" class="panel woocommerce_options_panel" style="display:block"> <?php
        ?><div class="options_group show_if_simple show_if_variable">
        <?php
        woocommerce_wp_text_input( array(
            'id' => 'aliquota_piva_vies',
            'label' => __( 'Product tax rate', 'woocommerce_vies' ),
            'desc_tip' => 'true',
            'description' => __( 'Enter the percentage tax rate of this product (ex 4 - 10 - 22)', 'woocommerce_vies' ),
            'type' => 'text',
        ) );
        ?>
        </div>
        </div> <?php

    }
    add_action( 'woocommerce_product_data_panels', 'my_custom_product_tab_content' );

    add_action( 'woocommerce_process_product_meta', 'save_custom_field' );
    function save_custom_field( $post_id ) {
      
        $custom_field_value = isset( $_POST['aliquota_piva_vies'] ) ? $_POST['aliquota_piva_vies'] : '';
      
        $product = wc_get_product( $post_id );
        $product->update_meta_data( 'aliquota_piva_vies', $custom_field_value );
        $product->save();
    }*/


    // ================================================================================= Includi settings.php per la pagina impostazioni dell'area admin

    include 'settings.php';
}

//=================== Funzione traduzione

/*
function traduci($string){
    return $string;
}
*/

?>
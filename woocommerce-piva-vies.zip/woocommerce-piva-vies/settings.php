<?php
function add_order_number_start_setting( $settings ) {

   $updated_settings = array(
        array(
            'name'     => __( "Settings of VAT number with Vies Control's", 'woocommerce_vies' ),
            'type'     => 'title',
            'desc'     => 'Queste sono le impostazioni generali. Il plugin calcola l\'IVA di ogni prodotto che viene inserita specificatamente in ogni pagina prodotto nel relativo pannello Aliquota VIES.',
            'id'       => 'piva_vies_section_title'
        ),
        array(
            'name'     => __( 'Enable Vies Control', 'woocommerce_vies' ),
            'type'     => 'checkbox',
            'id'       => 'check_vies_plugin'
        )
    );
    if( get_option('check_vies_plugin') == 'yes' ){
        $updated_settings = array_merge($updated_settings,
                array(
                    array(
                        'name' => __( 'Country Code', 'woocommerce_vies' ),
                        'type' => 'text',
                        //'desc' => __( 'This is some helper text', 'woocommerce_vies' ),
                        'id'   => 'piva_vies_section_codice_nazione'
                    ),
                    array(
                        'name' => __( 'VAT number', 'woocommerce_vies' ),
                        'type' => 'text',
                        //'desc' => __( 'This is some helper text', 'woocommerce_vies' ),
                        'id'   => 'piva_vies_section_piva'
                    ),
                    array(
                        'name' => __( 'Green color of convalidation', 'woocommerce_vies' ),
                        'type' => 'text',
                        //'desc' => __( 'This is some helper text', 'woocommerce_vies' ),
                        'id'   => 'piva_vies_section_verde'
                    ),
                    array(
                        'name' => __( 'Red color of convalidation', 'woocommerce_vies' ),
                        'type' => 'text',
                        //'desc' => __( 'This is some helper text', 'woocommerce_vies' ),
                        'id'   => 'piva_vies_section_rosso',
                    ) 
                )
            );
    }
    $updated_settings = array_merge($updated_settings,
            array(
                array(
                    'type' => 'sectionend',
                    'id' => 'wc_settings_tab_piva_vies_section_end'
                )
            )
        );
    $result = array();
    foreach ($settings as $section) {
        $result[] = $section;
    }
    foreach ($updated_settings as $section) {
        $result[] = $section;
    }

    /*
    echo '<pre>';
    print_r($result);
    echo '</pre>';*/

    
    return $result;


}

add_filter( 'woocommerce_tax_settings', 'add_order_number_start_setting' );

?>
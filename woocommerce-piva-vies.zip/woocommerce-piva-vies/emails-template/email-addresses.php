<?php
/**
 * Email Addresses
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/email-addresses.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     3.2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$text_align = is_rtl() ? 'right' : 'left';

?><table id="addresses" cellspacing="0" cellpadding="0" style="width: 100%; vertical-align: top; margin-bottom: 40px; padding:0;" border="0">
	<tr>
		<td style="text-align:<?php echo $text_align; ?>; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; border:0; padding:0;" valign="top" width="100%">
			<h2><?php _e( 'Billing address', 'woocommerce' ); ?></h2>

			<address class="address">
				<?php echo ( $address = $order->get_formatted_billing_address() ) ? $address : __( 'N/A', 'woocommerce' ); ?>
				<?php if ( $order->get_billing_phone() ) : ?>
					<br/><?php echo esc_html( $order->get_billing_phone() ); ?>
				<?php endif; ?>
				<?php if ( $order->get_billing_email() ) : ?>
					<br/><?php echo esc_html( $order->get_billing_email() ); ?><br/>
				<?php endif; ?>
				<?php 
				$meta = get_post_meta( $order->id, '_billing_partita_iva', true );
				if ( $meta ) : ?>
					<?php echo 'Partita IVA: '. $meta; ?>
				<?php endif; ?>
				<?php 
				$meta = get_post_meta( $order->id, '_billing_cod_fisc', true );
				if ( $meta ) : ?>
					<p><?php echo 'Codice Fiscale: '. $meta; ?></p>
				<?php endif; ?>
				<?php 
				$meta = get_post_meta( $order->id, '_billing_pec_email', true );
				if ( $meta ) : ?>
					<p><?php echo 'PEC: '. $meta; ?></p>
				<?php endif; ?>
				<?php 
				$meta = get_post_meta( $order->id, '_billing_codice_destinatario', true );
				if ( $meta ) : ?>
					<p><?php echo 'Codice Destinatario: '. $meta; ?></p>
				<?php endif; ?>

			</address>
		</td>
		
	</tr>
	<?php if ( ! wc_ship_to_billing_address_only() && $order->needs_shipping_address() && ( $shipping = $order->get_formatted_shipping_address() ) ) : ?>
	<tr>
		<td style="text-align:<?php echo $text_align; ?>; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; padding:20px 0 0;" valign="top" width="100%">
			<h2><?php _e( 'Shipping address', 'woocommerce' ); ?></h2>

			<address class="address"><?php echo $shipping; ?></address>
		</td>
	</tr>
	<?php endif; ?>
</table>

<?php

function traduci_string($string){
	global $sublanguage;
	$lang = $sublanguage->current_language->post_name;
    $list = array(
        'Partita IVA' => array(
            'en' => 'VAT number'
        ),
        'Codice Fiscale' => array(
            'en' => 'Fiscal Code'
        ),
    );
    if ($lang != 'it') {
        return $list[$string][CURRENTLANG];
    }
    return $string;
    
}
?>
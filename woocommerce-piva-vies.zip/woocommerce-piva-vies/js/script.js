if(!obj_var.rosso){
    obj_var.rosso = 'red';
}
if(!obj_var.verde){
    obj_var.verde = 'green';
}

jQuery(document).ready(function(){
    if( obj_var.check_active == 'yes' ){

        jQuery('#billing_partita_iva_field .woocommerce-input-wrapper').append('<div id="validatePiva" style="background:'+obj_var.rosso+';"><img src="'+obj_var.plugin_url+'/woocommerce-piva-vies/images/false.png"></div>');

        jQuery('#validatePiva').on('click', function(){
            verificaPiva();
        });
        jQuery('#billing_partita_iva').bind('keyup keydown focusout',function(){
            if(jQuery('#billing_partita_iva').val().length > 6){
                verificaPiva();
            }
        });

        //jQuery('#billing_cod_fisc_field .woocommerce-input-wrapper').append('<div id="validateCF" style="background:'+obj_var.rosso+';"><img src="'+obj_var.plugin_url+'/woocommerce-piva-vies/images/false.png"></div>');

        /*jQuery('#validateCF').on('click', function(){
            verificaCF();
        });
        jQuery('#billing_cod_fisc').bind('keyup keydown focusout',function(){
            if(jQuery('#billing_cod_fisc').val().length > 6){
                verificaCF();
            }
        });*/
    }
})

jQuery('#billing_country').on('change',function(){
    verificaPiva();
})

function verificaPiva(){
    var stato = jQuery('#billing_country').val();
    var piva = jQuery('#billing_partita_iva').val();


    jQuery.ajax({
        url: obj_var.plugin_url + "/woocommerce-piva-vies/verificapiva.php",
        type: "POST",
        data: {
           codiceStato: stato,
           piva: piva,
           mioCodiceStato: obj_var.codiceNazione,
           miaPiva: obj_var.pIva,
        },
        beforeSend: function(){ jQuery("#validatePiva img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/spinner-piva.gif');},
        //complete: function(){ jQuery("#validatePiva img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/false.png'); },
        success  : function(msg){
            //console.log(msg);
            var parts = msg.split(":");
            jQuery(".tax-total td span").html(parts[1]);
            jQuery(".order-total td span").html(parts[0]);
            //console.log(msg);
            if(parts[2] == 0){
                jQuery('#billing_partita_iva').css('border','1px solid '+obj_var.rosso);
                jQuery("#validatePiva img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/false.png');
                jQuery('#validatePiva').css('background',obj_var.rosso);
                jQuery('tr.shipping').show();
            }
            else{
                jQuery('#billing_partita_iva').css('border','1px solid '+obj_var.verde);
                jQuery("#validatePiva img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/true.png');
                jQuery('#validatePiva').css('background',obj_var.verde);
                //jQuery('tr.shipping').hide();
            }
        } ,
        error    : function(msg) { console.log('Failed'); } 
      });
}
function verificaCF(){
    var stato = jQuery('#billing_country').val();
    var cfiscale = jQuery('#billing_cod_fisc').val();


    jQuery.ajax({
        url: obj_var.plugin_url+"/woocommerce-piva-vies/verifica_cf.php",
        type: "POST",
        data: {
           codiceStato: stato,
           cfiscale: cfiscale,
        },
        beforeSend: function(){ jQuery("#validateCF img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/spinner-piva.gif');},
        //complete: function(){ jQuery("#validateCF img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/false.png'); },
        success  : function(msg){
            //console.log(msg);   

            if(msg == 'invalid'){
                jQuery('#billing_cod_fisc').css('border','1px solid '+obj_var.rosso);
                jQuery("#validateCF img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/false.png');
                jQuery('#validateCF').css('background',obj_var.rosso);
            }else{
                jQuery('#billing_cod_fisc').css('border','1px solid '+obj_var.verde);
                jQuery("#validateCF img").attr('src',obj_var.plugin_url+'/woocommerce-piva-vies/images/true.png');
                jQuery('#validateCF').css('background',obj_var.verde);
            }
        } ,
        error    : function(msg) { console.log('Failed'); } 
      });
}
function switch_fields(){
    var billing_method_type = jQuery("#billing_method_type").val();

    if( billing_method_type == 'pec'){
        jQuery("#billing_codice_destinatario").attr('value','');
        jQuery('#billing_codice_destinatario').val(null);
        jQuery('#billing_pec_email_field').show();
        jQuery('#billing_codice_destinatario_field').hide();
        if(!jQuery('.woocommerce #billing_pec_email_field label abbr.required').length){
            jQuery(".woocommerce #billing_pec_email_field label").append("<abbr class=\"required\">*</abbr>");
        }
        jQuery(".woocommerce #billing_codice_destinatario_field label abbr.required").remove();
    }
    if( billing_method_type == 'codice_destinatario'){
        jQuery('#billing_pec_email').val(null);
        jQuery("#billing_codice_destinatario").prop('disabled',false);
        jQuery('#billing_codice_destinatario_field').show();
        jQuery('#billing_pec_email_field').hide();
        if(!jQuery('.woocommerce #billing_codice_destinatario_field label abbr.required').length){
            jQuery(".woocommerce #billing_codice_destinatario_field label").append("<abbr class=\"required\">*</abbr>");
        }
        jQuery(".woocommerce #billing_pec_email_field label abbr.required").remove();
    }

    /*if( billing_method_type == 'altro'){
        jQuery("#billing_codice_destinatario").val('000000');
        jQuery("#billing_codice_destinatario").attr('value','000000');
        jQuery("#billing_codice_destinatario").prop('disabled',true);
    }*/
    if( billing_method_type == 'not_selected' || billing_method_type == 'altro'){
        jQuery('#billing_pec_email').val(null);
        jQuery('#billing_pec_email_field').hide();
        jQuery("#billing_codice_destinatario").attr('value','');
        jQuery("#billing_codice_destinatario").val(null);
        jQuery("#billing_codice_destinatario").prop('disabled',false);
        jQuery('#billing_codice_destinatario_field').hide();
    }

    switch(jQuery("#billing_invoice_type").val()){
        case 'azienda':
            jQuery("#billing_company_field").show();
            jQuery('#billing_partita_iva_field').show();

            if(!jQuery('.woocommerce #billing_partita_iva_field label abbr.required').length){
                jQuery(".woocommerce #billing_partita_iva_field label").append("<abbr class=\"required\">*</abbr>");
            }
            
            if(!jQuery('.woocommerce #billing_company_field label abbr.required').length){
                jQuery(".woocommerce #billing_company_field .optional").hide();
                jQuery(".woocommerce #billing_company_field label").append("<abbr class=\"required\" title=\"obbligatorio\">*</abbr>");
            }
            break;

        case 'privato':
            jQuery("#billing_company_field").hide();
            jQuery(".woocommerce #billing_partita_iva_field").hide();

            jQuery(".woocommerce #billing_company_field .optional").show();
            jQuery(".woocommerce #billing_company_field label abbr.required").remove();
            break;
        default:
            jQuery(".woocommerce #billing_company_field").hide();
            jQuery(".woocommerce #billing_partita_iva_field").hide();
            jQuery(".woocommerce #billing_pec_email_field").hide();
            jQuery(".woocommerce #billing_codice_destinatario_field").hide();
            
            jQuery(".woocommerce #billing_company_field .optional").show();
            jQuery(".woocommerce #billing_company_field label abbr.required").remove();
            break;
    }
}

jQuery(document).ready(function() {
    jQuery(".woocommerce #billing_company_field").hide();
    jQuery(".woocommerce #billing_partita_iva_field").hide();
    jQuery(".woocommerce #billing_pec_email_field").hide();
    jQuery(".woocommerce #billing_codice_destinatario_field").hide();
    jQuery(".woocommerce #billing_partita_iva_field .optional").remove();
    jQuery(".woocommerce #billing_pec_email_field .optional").remove();
    jQuery(".woocommerce #billing_codice_destinatario_field .optional").remove();
    jQuery("#billing_invoice_type, #billing_method_type").change(function(){
    	switch_fields();
    });
    switch_fields();
});
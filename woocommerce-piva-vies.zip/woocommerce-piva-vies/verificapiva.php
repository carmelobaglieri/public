<?php 
require '../../../wp-load.php';

$country1 = $_POST["codiceStato"];
$country2 = $_POST["mioCodiceStato"];
$vatnum1 = $_POST['piva'];
$vatnum2 = $_POST['miaPiva'];

//check se utente inserisce codice stato nel campo piva
$sub = substr($vatnum1, 0,2);
if($sub == $country1){
	$vatnum1 = substr($vatnum1, 2);
}

$regexPIVA = "/^(ATU[0-9]{8}|BE0[0-9]{9}|BG[0-9]{9,10}|CY[0-9]{8}L| CZ[0-9]{8,10}|DE[0-9]{9}|DK[0-9]{8}|EE[0-9]{9}|(EL|GR)[0-9]{9}|ES[0-9A-Z][0-9]{7}[0-9A-Z]|FI[0-9]{8}|FR[0-9A-Z]{2}[0-9]{9}|GB([0-9]{9}([0-9]{3})?|[A-Z]{2}[0-9]{13})|HU[0-9]{8}|IE[0-9]S[0-9]{5}L|IT[0-9]{11}|LT([0-9]{9}|[0-9]{12})|LU[0-9]{8}|LV[0-9]{11}|MT[0-9]{8}|NL[0-9]{9}B[0-9]{2}|PL[0-9]{10}|PT[0-9]{9}|RO[0-9]{2,10}|SE[0-9]{12}|SI[0-9]{8}|SK[0-9]{10})$/i";

$codStates = array('AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'EL' , 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'GB');



//Prepare the URL
$url = 'http://ec.europa.eu/taxation_customs/vies/viesquer.do?ms='.$country1.'&iso='.$country1.'&vat='.$vatnum1.'&name=&companyType=&street1=&postcode=&city=&requesterMs='.$country2.'&requesterIso='.$country2.'&requesterVat='.$vatnum2.'&BtnSubmitVat=Verify';

//echo $url;

$response = file_get_contents($url);

global $woocommerce, $wpdb;
$prefix = $wpdb->prefix;

$iva = 0;
foreach ($woocommerce->cart->cart_contents as $item) {
	$tax = get_post_meta($item['product_id'],'_tax_class',true);
	$tax = ($tax) ? $tax : '';
	$perc_vat = $wpdb->get_var( "SELECT tax_rate FROM {$prefix}woocommerce_tax_rates WHERE tax_rate_class = '$tax'" );

	$iva += $item['line_subtotal'] * intval($perc_vat) / 100;
}

if(in_array($country1, $codStates)){
	if(preg_match($regexPIVA, $country1.$vatnum1)){

		if ($_POST["codiceStato"] == 'IT') {
		  $woocommerce->customer->set_is_vat_exempt(false);
		  echo (number_format($woocommerce->cart->subtotal_ex_tax+$iva,2,',','.'))."€:".number_format($woocommerce->cart->subtotal_ex_tax+$iva-$woocommerce->cart->subtotal_ex_tax,2,',','.')."€:1:".number_format($woocommerce->cart->total);
		}
		else {
			if(strpos($response, 'Yes, valid VAT number') !== false){
				$woocommerce->customer->set_is_vat_exempt(true);
				echo number_format($woocommerce->cart->subtotal_ex_tax,2,',','.')."€:0.00€:1:".number_format($woocommerce->cart->total);
			}else{
				$woocommerce->customer->set_is_vat_exempt(false);
				echo (number_format($woocommerce->cart->subtotal_ex_tax+$iva,2,',','.'))."€:".number_format($woocommerce->cart->subtotal_ex_tax+$iva-$woocommerce->cart->subtotal_ex_tax,2,',','.')."€:0:".number_format($woocommerce->cart->total);
			}
		}
	}else{
		$woocommerce->customer->set_is_vat_exempt(false);
		echo (number_format($woocommerce->cart->subtotal_ex_tax+$iva,2,',','.'))."€:".number_format($woocommerce->cart->subtotal_ex_tax+$iva-$woocommerce->cart->subtotal_ex_tax,2,',','.')."€:0:".number_format($woocommerce->cart->total);
	}
}else{
	$woocommerce->customer->set_is_vat_exempt(false);
		echo (number_format($woocommerce->cart->subtotal_ex_tax+$iva,2,',','.'))."€:".number_format($woocommerce->cart->subtotal_ex_tax+$iva-$woocommerce->cart->subtotal_ex_tax,2,',','.')."€:1:".number_format($woocommerce->cart->total);
}

?>
/*events*/
jQuery('#add-odds').on('click touchstart', function(){
	calculator.clone();
})

jQuery('#odds-reset').on('click touchstart', function(){
	calculator.reset();
})

jQuery(document).on('change', '#odds-stake, .all-odds input', function(){
	jQuery(this).val( calculator.formatNumber(jQuery(this).val(), jQuery(this).attr('data-type')) );
})

jQuery(document).on('keypress keyup', '#odds-stake, .all-odds input', function(e){
	calculator.validate(e, jQuery(this).attr('data-type'));
	calculator.calcPayout();
})

jQuery(document).on('change', '#odds-format', function(){
	calculator.updateOddsFormat();
})
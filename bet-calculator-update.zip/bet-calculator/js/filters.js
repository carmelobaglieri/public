var filterClass = function(options){

    /*
     * Variables accessible
     * in the class
     */
    var vars = {
        ajax_url : '',
        favourite_sport : '',
        format: '',
        find: '',
        sportsData  : {},
        oddsData : {},
        refresh: 0
    };

    /*
     * Can access this.method
     * inside other methods using
     * root.method()
     */
     var root = this;

    /*
     * Constructor
     */
    this.construct = function(options){
        jQuery.extend(vars , options);
        root.renderSports();
        root.renderBet();
        if( vars.refresh > 0 ){
            setInterval(function(){
                vars.oddsData = {};
                root.renderBet() 
            }, (vars.refresh * 1000));
        }
    };

    this.getFavouriteSport = function(){
        return vars.favourite_sport;
    }

    this.setFavouriteSport = function(key){
        vars.favourite_sport = key;
        root.renderSports(vars.find);
        if( get_odds_data() == undefined ){
            load_odds_data();
        }else{
            root.renderBet();
        }
        return;
    }

    this.setFind = function(key){
        vars.find = key;
        root.renderSports(vars.find);
        return;
    }

    this.getRegion = function(){
        var bet = root.getBet();
        return bet.region;
    }

    this.setRegion = function(key){
        var bet = root.getBet();
        bet.region = key;
        updateBet(bet);
        vars.oddsData = {};
        root.renderBet();
        return;
    }

    this.setFormat = function(key){
        var bet = root.getBet();
        bet.format = key;
        updateBet(bet);
        root.renderBet();
        return;
    }

    this.getFormat = function(){
        var bet = root.getBet();
        return bet.format;
    }

    this.setBetType = function(el,event,type){
        event.preventDefault();
        jQuery('#betTypes a').removeClass('bg-secondary text-light active');
        var bet = root.getBet();
        bet.type = type;
        updateBet(bet,false);
        return;
    }

    this.setMultiStake = function(val){
        var bet = root.getBet();
        bet.multi_stake = val;
        updateBet(bet,false);
        return;
    }

    var getSportTitle = function(key){
        var sport = vars.sportsData.filter( function(item){
            return ( item.key == key );
        });
        return sport[0].title;
    }
    

    this.renderSports = function(find = ''){
        var groups = [];
        var html= '';

        jQuery.each(vars.sportsData, function(i, el){
            if( !groups.includes(el.group) ){
                groups.push(el.group);
                var item_found = false;
                var out = '';

                out += '<ul class="list-group mb-2"><li class="list-group-item py-1 px-2 bg-secondary text-light"><strong>'+ el.group + '</strong></li>';
                var sports = vars.sportsData.filter( function(item){
                    var title = item.title /*+ ' - ' + item.details*/;
                    if( item.group == el.group && 
                        (title.toLowerCase().indexOf(find.toLowerCase()) != -1 ||
                            el.group.toLowerCase().indexOf(find.toLowerCase()) != -1) ){
                        var classes = (item.key == root.getFavouriteSport()) ? 'active bg-accent' : '';
                        out += '<li class="list-group-item py-1 px-2 pointer '+classes+'" onClick="filters.setFavouriteSport(\''+item.key+'\');">'+ title + '</li>';
                        item_found = true;
                        return {title: title, key: item.key}
                    }
                })
                out += '</ul>';
                html += ( item_found ) ? out : '';
                /*vars.filtered.push({group: el.group, sports: sports});*/
            }
        })
       jQuery(".odds-calculator-wrap #filters_results").html(html);
       return;
    }

    this.renderGrid = function(sport = root.getFavouriteSport()){
        var html = '';
        var data = get_odds_data(sport);

        if( data == undefined ){
            html = '<div class="py-3">' + getSpinner() + '</div>';
        }else{

            var ts = Math.round((new Date()).getTime() / 1000);

            jQuery.each( data, function(i,el){
                if( el.sites_count){
                    /*header*/
                    if( i == 0 ){
                        var h2h_len = el.sites[0].odds.h2h.length;
                        var header = '<li class="list-group-item head py-0 px-2 bg-secondary text-white">';
                        header += '<div class="row justify-content-end">';
                        header += '<div class="col-xl-4 col-lg-5">';
                        header += '<div class="row no-gutters text-center">';
                        header +=     '<div class="col-'+(12/h2h_len)+' px-1">1</div>';
                        if( h2h_len > 2 ){
                            header += '<div class="col-'+(12/h2h_len)+' px-1">X</div>';
                        }
                        header +=     '<div class="col-'+(12/h2h_len)+' px-1">2</div>';
                        header += '</div></div></div></li>';
                        html += header;
                    }
                }
                /*check match already started*/
                if(ts < el.commence_time){ 
                    html += '<li class="list-group-item p-2" data-sport="'+sport+'" data-match="'+i+'">';
                    html += '<div class="row align-items-center">';
                    /*match*/
                    html += '<div class="col-xl-5 col-lg-4 col-md-6 match">';
                    html +=     '<h4 class="my-0">' + el.home_team + '</h4>';
                    html +=     '<h4 class="mt-0 mb-1">' + getVs(sport, i) + '</h4>';
                    html +=     '<h5 class="my-0 text-muted">' + formatDate(el.commence_time) + '</h5></div>';
                    if( el.sites_count){
                        html += '<div class="col-md-3 sites">';
                        /*sites*/
                        html += renderSites(sport, i) + '</div>'; 
                        /*odds*/
                        html += '<div class="col-xl-4 col-lg-5 quote">';
                        html += root.renderOdds(sport, i, sortAsc(el.sites, "site_key")[0].site_key)+'</div>';

                    }else{
                        html += '<div class="col-md-7"><p class="text-center">No odds available</p></div>';
                    }
                html += '</div></li>';
                }
            });
        }
        jQuery('#odds').html(html);
        return;
    }

    this.renderOdds = function(sport, match, site){
        if( get_odds_data() == undefined ){
            return;
        }
        var list = get_odds_data()[match].sites.filter(function(el){
            return ( el.site_key == site );
        })
        var html = '<div class="row no-gutters">';
        jQuery.each( list[0].odds.h2h, function(j,val){
            html += '<div class="col-'+(12/list[0].odds.h2h.length) +' px-1">';
            var classes = ( is_on_bet(sport,match, site, j) ) ? 'bg-accent' : 'btn-outline-secondary';
            html += '<span class="btn '+classes+' btn-sm btn-block px-1" ';
            html += 'data-match="'+ match +'" ';
            html += 'data-site="'+ site +'" ';
            html += 'data-h2h="'+ j +'" ';
            html += "onClick='filters.addToBet(\""+sport+"\","+match+",\""+site+"\","+j+");jQuery(this).toggleClass(\"btn-outline-secondary bg-accent\");'>"+ val +"</span></div>";
        });
        html += '</div>';
        return html;
    }

    this.addToBet = function(sport, match, site, h2h){
        var bet = root.getBet();
        console.log(bet)
        if( is_on_bet(sport,match, site, h2h) ){
            bet.data.splice(getBetOddIndex(sport,match, site, h2h),1);
            updateBet(bet, false)
            return;
        }

        var obj = {};
        obj.sport = sport;
        obj.match = match;
        obj.commence_time = get_odds_data()[match].commence_time;
        obj.site = site;
        obj.h2h = h2h;
        obj.h2h_val = root.formatOdd(getSingleOdd(obj.sport,match,site, h2h),'decimal');
        obj.stake = 0;
        obj.win = 0;
        bet.data.push(obj);
        updateBet(bet,false);
        return;
    }

    this.renderBet = function(renderGrid = true){

        jQuery('.odds-calculator-wrap').removeClass('tablet mobile');
        jQuery('.odds-calculator-wrap').addClass(root.getScreen());
        
        var bets_ticket = root.getBet();
        /*topbar*/
        jQuery('#odds-format').val(root.getFormat());
        jQuery('#odds-region').val(root.getRegion());

        /*tabs*/
        jQuery('#betTypes a[data-value="'+bets_ticket.type+'"]').addClass('bg-secondary text-light active');
        /*initialize data with sport selected */
        if(get_odds_data() == undefined ){
            load_odds_data();
            jQuery('#bet').html(getSpinner());
            return;
        }
        var html = '';
        if( bets_ticket.data.length ){
            var bet = sortAsc(bets_ticket.data, "commence_time");
            /*reset button*/
            html += '<div class="text-right">';
            html += '<span class="text-light py-0 px-2 pointer" onClick="filters.resetBet()">';
            html += '<i class="fa fa-times"></i> Remove all</span></div>';
            /*odds*/
            html += '<div class="bet-card">';
            html += '<ul class="list-group mt-0">';
            jQuery.each( bet, function(i, el){
                /* warning duplicate match on multiple */
                if( bets_ticket.type == 'multiple' && hasDuplicate(el.match)){
                    html += '<li class="list-group-item bg-danger px-2 lh-1">';
                    html += '<h6 class="mt-0 mb-1 text-white">Duplicated</h6>';
                    html += '<small class="text-light">This selection is correlated with another selection. ';
                    html += 'Please remove it for continue with multiple bet.</small></li>';
                    
                }
                html += '<li class="list-group-item px-2">';
                /*remove button*/
                html += '<span class="remove" onClick="filters.removeOdd('+i+')">';
                html += '<i class="fa fa-times"></i></span>';
                /*get new data if not present*/
                if( get_odds_data(el.sport) == undefined ){
                    load_odds_data(el.sport);
                    html += getSpinner();
                }else{
                    var home_team = get_odds_data(el.sport)[el.match].home_team;
                    html += '<h5 class="card-title mt-0">' + home_team + ' - ' + getVs(el.sport, el.match) + '</h5>';
                    html += '<h6 class="card-subtitle text-muted mb-2">' + getSportTitle(el.sport) + '</h6>';
                    /* home_team and odd */
                    html += '<div class="row no-gutters align-items-center mb-1">';
                    html += '<div class="col-sm-8 pr-1">';
                    html += '<h6 class="m-0">' + getChoiseName(el.sport,el.match, el.h2h)+'</h6>';
                    html += '<h6 class="m-0 mb-1 text-muted">' + el.site +'</h6></div>';
                    html += '<div class="col-sm-4 text-right"><span class="bg-accent px-1" ';
                    var value = root.formatOdd(getSingleOdd(el.sport,el.match,el.site, el.h2h));
                    html += 'data-value="'+value+'">' + value + '</span></div>';
                    html += '</div>';
                    
                    /*single*/
                    if( bets_ticket.type == 'single'){
                        html += '<div class="row no-gutters">';
                        html += '<div class="col-6 pr-1">';
                        var value = (bets_ticket.data[i].stake) ? bets_ticket.data[i].stake : "";
                        html += '<input type="text" class="form-control stake text-center" placeholder="Stake" value="'+value+'" ';
                        html += 'onKeypress="filters.validate(event)" ';
                        html += 'onChange="this.value = filters.formatOdd(this.value,\'decimal\');';
                        html += 'filters.updateStake('+i+',this.value);">';
                        html += '</div><div class="col-6">';
                        var value = (bets_ticket.data[i].stake) ? bets_ticket.data[i].win : "";
                        html += '<input disabled type="text" class="form-control win text-center" placeholder="Win" value="'+value+'"';
                        html += 'onKeypress="filters.validate(event)" ';
                        html += 'onChange="this.value = filters.formatOdd(this.value,\'decimal\');">';
                        html += '</div></div>';
                    }
                }

                html += '</li>';
            });

            html += '<li class="list-group-item px-2">'+ renderPayout(bets_ticket)+'</li>';
            html += '</ul>';
            html += '</div>';
        }else{
            html += '<p class="text-center text-light">Add bets to start</p>';
        }
        jQuery('#bet').html(html);
        if(renderGrid){
            console.log(renderGrid)
            root.renderGrid();
        }
        return;
    }

    this.getBet = function(){
        if( getCookie('bets_ticket') == null){
            initCookie('bets_ticket', emptyBet(), 1);
        }
        return JSON.parse(getCookie('bets_ticket'));
    }

    this.resetBet = function(){
        updateBet(JSON.parse(emptyBet()));
        return;
    }

    this.removeOdd = function(el){
        var bet = root.getBet();
        bet.data.splice(el, 1);
        updateBet(bet);
        return;
    }

    /*
    * Private methods
    */

    var sortAsc = function(arr, key){
        var list = arr.sort(function(a,b){
            if(a[key] < b[key]) { return -1; }
            if(a[key] > b[key]) { return 1; }
            return 0;
        });
        return list;
    };

    var renderSites = function(sport, match){
        var html = '';
        var data = get_odds_data(sport)[match];
        jQuery.each( sortAsc(data.sites, "site_key"), function(i,site){
            if( i == 0 ){
                var s = "jQuery('#odds li[data-match="+match+"] .quote').html(filters.renderOdds('"+sport+"',"+match+",this.value))";
                html += '<select class="form-control" onChange="'+s+'">';
            }
            html +=  '<option value="'+ site.site_key +'">'+ site.site_nice +'</span>';
            if( (i+1) == data.sites_count ){
                html += '</select>';
            }
        });
        return html;
    }

    var emptyBet = function(){
        return '{"type": "single", "format": "decimal", "region": "us", "data": [], "multi_stake": ""}';
    }

    var renderPayout = function(bet){
        var html = '';
        if(bet.type == 'multiple'){
            html = '<div class="mb-2">';
            var value = (bet.multi_stake) ? bet.multi_stake : "";
            html += '<input type="text" class="form-control stake text-center" placeholder="Stake" value="'+value+'" ';
            html += 'onKeypress="filters.validate(event)" ';
            html += 'onChange="this.value = filters.formatOdd(this.value,\'decimal\');';
            html += 'filters.setMultiStake(this.value);">';
            html += '</div>';
        }

        html += '<div class="row">';
        html += '<div class="col-md-6"><h6 class="m-0 mb-1">Total stake</h6></div>';
        html += '<div class="col-md-6"><h6 class="m-0 mb-1 text-right">$<span id="totalStake">'+getTotalStake(bet)+'</span></h6></div></div>';
        html += '<div class="row">';
        html += '<div class="col-md-6"><h5 class="m-0 mb-1">Total Win</h5></div>';
        html += '<div class="col-md-6"><h5 class="m-0 mb-1 text-right">$<span id="totalPayout">'+getTotalWin(bet)+'</span></h5></div></div>';
        return html;
    }

    var getBetOddIndex = function(sport, match, site, h2h){
        var bet = root.getBet();
        var index = null;
        jQuery.each( bet.data, function(i,el){
            if( sport == el.sport && match == el.match && site == el.site && h2h == el.h2h){
                index = i;
            }
        })
        return index;
    }

    var get_odds_data = function(sport = root.getFavouriteSport()){
        return vars.oddsData[sport];
    }

    var hasDuplicate = function(match){
        var d = root.getBet().data.filter(function(el){
            return ( el.match == match );
        });
        return ( d.length > 1 );
    }

    var formatDate = function(d){
        var date = new Date(d * 1000);
        return date.toLocaleString();
    }

    var getVs = function(sport,i){
        var match = get_odds_data(sport)[i];
        var vs = match.teams.filter(function(el){
            return el != match.home_team;
        });
        return vs[0];
    }

    var load_odds_data = function(sport = root.getFavouriteSport(), region = root.getRegion()) {
        jQuery.ajax({
            url: vars.ajax_url,
            dataType: "json",
            type: "POST",
            data: {
                "action" : "get_odds",
                "sport"  : sport,
                "region" : region,
                "mkt"    : "{mkt}"
            },
            beforeSend: function(){
                jQuery('#odds').html('<div class="py-3">' + getSpinner() + '</div>');
            },
            success: function(response){
                if(response == null || response.message == "Key doesn't exists"){
                    root.resetBet();
                    jQuery('#odds').html('<span class="text-light">You must add a valid API KEY</span>');
                    jQuery('#bet').html('');
                    return;
                }
                vars.oddsData[sport] = response.data;
                root.renderBet();
            },
            error: function(msg){
                console.log(msg)
            }
        });
        return; 
    };

    /*var getSportsData = function() {
        jQuery.ajax({
            url: vars.ajax_url,
            async: false,
            dataType: "json",
            type: "POST",
            data: {"action" : "get_sports"},
            success: function(response){
                vars.sportsData = response.data;
                root.renderSports();
                root.renderBet();
            },
            error: function(msg){
                console.log(msg)
            }
        });
        return; 
    };*/

    var updateBet = function(val,refreshGrid = true){
        initCookie('bets_ticket', JSON.stringify(val), 1);
        root.renderBet(refreshGrid);
        return;
    }

    var initCookie = function(name, value, days){
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 *1000));
        var expires = "; expires=" + date.toGMTString();
        document.cookie = name + "=" + value + expires + "; path=/";
    }

    var getCookie = function(name){
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') {
                c = c.substring(1,c.length);
            }
            if (c.indexOf(nameEQ) == 0) {
                return c.substring(nameEQ.length,c.length);
            }
        }
        return null;
    }

    var getSpinner = function(){
        var html = '<div class="text-center"><div class="spinner-border" role="status">';
        html += '<span class="sr-only">Loading...</span></div></div>';
        return html;
    }

    var getSingleOdd = function(sport, match, site, h2h){
        var s = get_odds_data(sport)[match].sites.filter(function(el){
            return ( el.site_key == site );
        });
        return s[0].odds.h2h[h2h]
    }

    var is_on_bet = function(sport, match, site, h2h){
        var bet = root.getBet();
        var s = bet.data.filter(function(el){
            return ( sport == el.sport && match == el.match && site == el.site && h2h == el.h2h);
        });
        return ( s.length )
    }

    var getChoiseName = function(sport, match, h2h){
        switch( h2h ){
            case 0:
                return get_odds_data(sport)[match].home_team;
            case 2:
                return getVs(sport, match);
            default:
                return 'Draw';
        }
    }

    this.formatOdd = function(val, type = root.getFormat()){
        if( val == '' ){
            return val;
        }
        var calc = null;
        val = parseFloat(val);
        switch( type ){
            case 'american':
                if( val >= 2.000 ){
                    calc = '+' + ((val - 1) * 100).toFixed(0);
                }else{
                    calc = ( -100 / (val - 1)).toFixed(0);
                }
                return calc;
            case 'fractal':
                calc = val - 1;
                var countDec = countDecimals(calc);
                var numerator = calc * Math.pow(10, countDec);
                var denominator = Math.pow(10, countDec);
                calc = reduce(numerator, denominator);
                if( calc[0] > 999 || calc[1] > 999 ){
                    return val.toFixed(3);
                }
                return calc[0] + '/' + calc[1];
            case 'decimal':
                return val.toFixed(3);
        }
    }

    var countDecimals = function (num) {
        if(Math.floor(num.valueOf()) === num.valueOf()) return 0;
        return num.toString().split(".")[1].length || 0; 
    }

    var reduce = function(numerator,denominator){
        var gcd = function gcd(a,b){
            return b ? gcd(b, a%b) : a;
        };
        gcd = gcd(numerator,denominator);
        return [numerator/gcd, denominator/gcd];
    }

    this.validate = function (e, type){
        var permitted = ["0","1","2","3","4","5","6","7","8","9","."];
        if( permitted.includes(e.key) ){
            return;
        }
        e.preventDefault();
    }

    this.updateStake = function(index, val){
        var bet = root.getBet();
        bet.data[index].stake = val;
        bet.data[index].win = ((bet.data[index].h2h_val - 1) * bet.data[index].stake).toFixed(3);
        updateBet(bet, false);
        return;
    }

    var getTotalStake = function(bet){
        if( bet.type == 'single' ){
            var sum = 0.0;
            jQuery.each( bet.data, function(i, val){
                sum += parseFloat(val.stake);
            })
            return (sum) ? sum.toFixed(2) : "0.00";
        }else{
            return (bet.multi_stake) ? parseFloat(bet.multi_stake).toFixed(2) : "0.00";
        }
    }

    var getTotalWin = function(bet){
        if( bet.type == 'single' ){
            var sum = 0.0;
            jQuery.each( bet.data, function(i, val){
                sum += parseFloat(val.win);
            })
        }else{
            var sum = 1;
            jQuery.each( bet.data, function(i, val){
                sum *= val.h2h_val;
            })
            sum = (sum * bet.multi_stake) - bet.multi_stake;
        }
        return (sum) ? sum.toFixed(2) : "0.00";
    }

    this.getScreen = function(){
        if (window.matchMedia('(max-width: 767px)').matches){
            return 'tablet mobile';
        }else if(window.matchMedia('(max-width: 991px)').matches){
            return 'tablet';
        }else{
            return '';
        }
    }

    /*
     * Pass options when class instantiated
     */
    this.construct(options);

 };
 
 
var filters = new filterClass({ 
    ajax_url : _global.ajax_url,
    favourite_sport: _global.favourite_sport,
    sportsData: JSON.parse(_global.sports).data,
    refresh : _global.refresh
});

jQuery(window).on('resize',function(){
    jQuery('.odds-calculator-wrap').removeClass('tablet mobile');
    jQuery('.odds-calculator-wrap').addClass(filters.getScreen());
})

jQuery('#toggleBet').on('click touchstart',function(){
    if(jQuery('#betWrap').css('bottom') != "0px"){
        jQuery('#betWrap').animate({
            bottom : 0
        });
    }else{
        jQuery('#betWrap').animate({
            bottom : '-100%'
        });
    }
})

jQuery('#filters input').on('focus keyup',function(){
    if( window.matchMedia('(max-width: 991px)').matches ){
        jQuery('#filters_results').slideDown(350)
    }
})

jQuery('body').on('click touchstart',function(e){
    if( window.matchMedia('(max-width: 991px)').matches ){
        var container = jQuery('#filters input');
        if (!container.is(e.target) && container.has(e.target).length === 0) {
                jQuery('#filters_results').slideUp(350);
        }
    }
})
<?php
/**
 * Plugin Name: Odds Calculator
 * Description: Calculate sport odds
 * Version:     1.0.1
 * Author:      Carmelo
 * Text Domain: odds_calculator
 */

/*abort*/
if ( ! defined( 'WPINC' ) ) {
	die;
}


if( ! function_exists('get_plugin_data') ){
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
$plugin_data = get_plugin_data( __FILE__ );
define( "ODDS_VER" , $plugin_data['Version']);
define( "ODDS_CALC_URL", plugin_dir_url(__FILE__));

if( is_admin()){
	include 'admin/options.php';
}

add_action('init', function(){
	require 'inc/functions.php';
});


add_action( 'wp_enqueue_scripts', function() {
	if(get_option('odds_calc_add_fonticon') == 'on'){
		wp_register_style( 'fontawesome', 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', null, '4.7.0', 'all' );
	}
	wp_register_style( 'odds-styles', ODDS_CALC_URL . 'css/styles.css', null, ODDS_VER, 'all' );
	wp_register_script( 'calculator', ODDS_CALC_URL . 'js/calculator.js', array('jquery'), ODDS_VER, true );
	wp_register_script( 'odds-scripts', ODDS_CALC_URL . 'js/scripts.js', array('jquery'), ODDS_VER, true );
	wp_localize_script( 
		'odds-scripts', 
		'_global',
		array( 
			'ajax_url' => admin_url( 'admin-ajax.php' ) 
	));
	wp_register_script( 'odds-filters', ODDS_CALC_URL . 'js/filters.min.js', array('jquery'), ODDS_VER, true );
	wp_localize_script( 
		'odds-filters', 
		'_global',
		array( 
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'api_key' => get_option('odds_calc_api_key'),
			'sports' => get_option('odds_calc_sports'),
			'favourite_sport' => get_option('odds_favourite_sport'),
			'refresh' => get_option('odds_timeout_refresh')
	));
}, 20);

add_shortcode('bet_calculator', function(){
	wp_enqueue_style('fontawesome');
	wp_enqueue_style('odds-styles');
	wp_enqueue_script('odds-filters');
	ob_start();
	include 'front/tpl.html';
	$out = ob_get_contents();
	ob_end_clean();
	return $out;
});

add_shortcode('odds_calculator', function(){
	wp_enqueue_style('fontawesome');
	wp_enqueue_style('odds-styles');
	wp_enqueue_script('calculator');
	wp_enqueue_script('odds-scripts');
	ob_start();
	include 'front/calculator.html';
	$out = ob_get_contents();
	ob_end_clean();
	return $out;
});

add_filter('plugin_action_links_'.plugin_basename(__FILE__), function( $links ) {
	$links[] = '<a href="' .
		admin_url( 'options-general.php?page=odds_calculator_settings' ) .
		'">' . __('Settings') . '</a>';
	return $links;
});
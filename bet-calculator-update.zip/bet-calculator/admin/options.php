<?php

/*add option page */
add_action( 'admin_init', function () {
	add_option( 'odds_calc_api_key', '' );
	add_option( 'odds_calc_add_fonticon', 'on' );
	$sports = file_get_contents(ODDS_CALC_URL . 'admin/sports.json');
	add_option( 'odds_calc_sports', $sports );
	$favourite = json_decode($sports);
	add_option( 'odds_favourite_sport', $favourite->data[0]->key);
	add_option( 'odds_timeout_refresh', '0');
	register_setting( 'odds_calc_group', 'odds_calc_api_key' );
	register_setting( 'odds_calc_group', 'odds_calc_add_fonticon' );
	register_setting( 'odds_calc_group', 'odds_favourite_sport' );
	register_setting( 'odds_calc_group', 'odds_timeout_refresh' );
		
});

add_action('admin_menu', function () {
	add_options_page(
		'Odds calculator settings', 
		'Odds calculator', 
		'manage_options', 
		'odds_calculator_settings',
		'odds_calculator_settings'
	);
});

function odds_calculator_settings(){
	?>
	<div>
		<h2>Odds calculator settings</h2>
		<p>Add <em>[odds_calculator] for show a simple payout calculator. Add <em>[bet_calculator]</em> for show bet simulator.</p>
		<form method="post" action="options.php">
			<?php 
			settings_fields( 'odds_calc_group' ); 
			do_settings_sections( 'odds_calc_group' );
			?>
			<table class="form-table">
				<tr valign="top">
					<th scope="row">
						<label for="odds_calc_api_key">API KEY</label>
					</th>
					<td>
						<input type="text" id="odds_calc_api_key" name="odds_calc_api_key" value="<?php echo get_option('odds_calc_api_key'); ?>" placeholder="API-KEY" />
						<p class="description">
							Get your key <a href="https://rapidapi.com/theoddsapi/api/live-sports-odds" target="_blank" title="RapidAPI - Get API key">here</a>. <br>
							<a href="https://docs.rapidapi.com/docs/basics-creating-a-project" target="_blank" title="RapidAPI - Consuming API">Read how consuming your API </a>
						</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for="odds_favourite_sport">Favourite Sport</label>
					</th>
					<td>
						<select type="text" id="odds_favourite_sport" name="odds_favourite_sport">
							<?php
							$sports = json_decode(get_option('odds_calc_sports'));
							$group = '';
							foreach ( $sports->data as $sport) {
								if( $group != $sport->group ){
									$group = $sport->group;
									echo '<optgroup label="'.$group.'">';
									$changed = false;
								}
								echo '<option '.selected( get_option('odds_favourite_sport'), $sport->key ).' value="'.$sport->key.'">'.$sport->title.' - '.$sport->details.'</option>';
								if( $changed ){
									echo '</optgroup>';
									$changed = true;
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for="odds_timeout_refresh">Timout refresh odds</label>
					</th>
					<td>
						<select type="text" id="odds_timeout_refresh" name="odds_timeout_refresh">
							<?php
							$times = array(0,60,120,180);
							foreach ( $times as $time) {
								echo '<option '.selected( get_option('odds_timeout_refresh'), $time ).' value="'.$time.'">'.$time.'</option>';
							}
							?>
						</select>
						<p class="description">Set when the odds need to upgrade value. 0 for unset
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for="odds_calc_add_fonticon">Include FontAwesome Icons</label>
					</th>
					<td>
						<input type="checkbox" id="odds_calc_add_fonticon" name="odds_calc_add_fonticon" <?php checked(get_option('odds_calc_add_fonticon'),'on','cheched'); ?> />
					</td>
				</tr>
			</table>
			<?php  submit_button(); ?>
		</form>
	</div>
	<?php
}